#include<stdio.h>
#include<conio.h>
//deletion
int main()
{
	int a[5],i,j,k;
	printf("enter five numbers\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter the number to be deleted\t");
	scanf("%d",&k);
	for(i=0;i<5;i++)
	{
		if(a[i]==k)
		{
			for(j=k+1;j<5;j++)
			a[j]=a[j+1];
		}
		break;
	}
	printf("\n");
	for(i=0;i<5;i++)
	{
		printf("%d\n",a[i]);
	}
}
