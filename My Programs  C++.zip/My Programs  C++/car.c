#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main()
{
int  gd=DETECT,gm;
int i;
initgraph(&gd,&gm,"C:/TURBOC3/BGI");
putpixel(130,400,12); //center of wheels
putpixel(330,400,12); //center of wheels
circle(130,400,30);   //wheel left
circle(330,400,30);  //wheel right
line(30,400,95,400);  //back body  starts here
line(30,400,35,350);
line(35,350,123,320);
line(123,320,150,250);
line(150,250,350,250);   //roof top of car
line(350,250,450,340);  //front part
line(450,340,530,350);
line(365,400,534,400);
line(530,350,535,400); //front body made here       its base line
line(165,400,295,400);
//making inner items
arc(130,400,5,175,35); //arc around first wheel
arc(330,400,5,175,35);//arc around second wheel
line(35,397,95,397);
line(35,397,40,355);
line(40,355,128,325);
getch();
closegraph();
}
#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main()
{
int  gd=DETECT,gm;
int i;
initgraph(&gd,&gm,"C:/TURBOC3/BGI");
putpixel(130,400,12); //center of wheels
putpixel(330,400,12); //center of wheels
circle(130,400,30);   //wheel left
circle(330,400,30);  //wheel right
line(30,400,95,400);  //back body  starts here
line(30,400,35,350);
line(35,350,123,320);
line(123,320,150,250);
line(150,250,350,250);   //roof top of car
line(350,250,450,340);  //front part
line(450,340,530,350);
line(365,400,534,400);
line(530,350,535,400); //front body made here       its base line
line(165,400,295,400);
//making inner items
arc(130,400,5,175,35); //arc around first wheel
arc(330,400,5,175,35);//arc around second wheel
line(35,397,95,397);
line(35,397,40,355);
line(40,355,128,325);
getch();
closegraph();
}

