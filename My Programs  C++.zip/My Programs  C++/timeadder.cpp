#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;
class tadd
{
	private:
		float sec;
		int min;
		int hr;
	public:
	    tadd()
	    {}
		tadd(int x)
		{
			cout<<"enter the seconds\t";
			cin>>sec;
			cout<<"enter the minutes\t";
			cin>>min;
			cout<<"enter the hours \t";
			cin>>hr;
			
	    }
	    void addtime(class tadd x)
	    {
	    	 tadd a;
	    	a.sec=sec+x.sec;
	    	if(a.sec>60)
	        a.min=min+x.min+a.sec/60;
			a.sec=fmod(a.sec,60.0);
	    	if(a.min>60)
            a.hr=hr+x.hr+a.min/60;
			a.min=a.min%60;
	    	a.display();
	    }
	    void display()
	    {
	    	cout<<"sum of time is\n"<<hr<<":"<<min<<":"<<sec<<"\n";
	    }
	    ~tadd()
	    {
	    	sec=min=hr=0;
	    }
};
int main()
{
	class tadd time1(8);
	cout<<endl<<endl;
	class tadd time2(0);
	//class tadd result;
	cout<<endl;
	time1.addtime(time2);
	//result.display();
	return 0;
}
	    	
