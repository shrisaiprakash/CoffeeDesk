#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<ctype.h>
#include<stdlib.h>
struct scorer
{
char *name;
int score;
};
void pixel_welcome();
void initial_name();
void game_name();
void ball();
void loading();
void bee_random();
void creature1();
void stone();
void cannon(int x,int y);
void option(int x,int y);
void down(int x,int y);
void up(int x,int y);
void hit(int x,int y);
void main_menu();
void line_border();
void high_score();
void rules();
void about();
void play();
void menu_option(char ch);
int gd=DETECT,gm;
int x,y;
void main()
{
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
clrscr();
pixel_welcome();
initial_name();
game_name();
ball();
loading();
closegraph();
main_menu();
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cannon(0,getmaxy()/2);
bee_random();
option(0,getmaxy()/2);
getch();
closegraph();
}
void pixel_welcome()
{
int x,y,i;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
for(i=0;i<=32500;i++)
{
x=rand()%getmaxx();
y=rand()%getmaxy();
putpixel(x+5,y+5,12);
}
delay(500);
settextstyle(EUROPEAN_FONT,HORIZ_DIR,2);
outtextxy(200,200,"W");
outtextxy(240,200,"E");
outtextxy(270,200,"L");
outtextxy(300,200,"-");
outtextxy(330,200,"C");
outtextxy(360,200,"O");
outtextxy(390,200,"M");
outtextxy(420,200,"E");
delay(1000);
cleardevice();
}
void initial_name()
{
//initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
x=getmaxx()/2-120;
y=100;
settextstyle(TRIPLEX_FONT,HORIZ_DIR,4);
outtextxy(x,y,"T");
delay(150);
outtextxy(x+20,y,"H");
delay(150);
outtextxy(x+40,y,"E");
delay(150);
outtextxy(x+60,y," ");
delay(150);
outtextxy(x+80,y,"B");
delay(150);
outtextxy(x+100,y,"E");
delay(150);
outtextxy(x+120,y,"E");
delay(150);
outtextxy(x+140,y," ");
delay(150);
outtextxy(x+160,y,"S");
delay(150);
outtextxy(x+180,y,"H");
delay(150);
outtextxy(x+200,y,"O");
delay(150);
outtextxy(x+220,y,"O");
delay(150);
outtextxy(x+240,y,"T");
delay(150);
outtextxy(x+260,y,"E");
delay(150);
outtextxy(x+280,y,"R");
delay(300);
cleardevice();
}
void game_name()
{
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
x=getmaxx()/2-120;
y=100;
delay(250);
setcolor(4);
settextstyle(TRIPLEX_FONT,HORIZ_DIR,4);
outtextxy(x,y,"T");
outtextxy(x+20,y,"H");
outtextxy(x+40,y,"E");
outtextxy(x+60,y," ");
outtextxy(x+80,y,"B");
outtextxy(x+100,y,"E");
outtextxy(x+120,y,"E");
outtextxy(x+140,y," ");
outtextxy(x+160,y,"S");
outtextxy(x+180,y,"H");
outtextxy(x+200,y,"O");
outtextxy(x+220,y,"O");
outtextxy(x+240,y,"T");
outtextxy(x+260,y,"E");
outtextxy(x+280,y,"R");
setcolor(15);
settextstyle(SCRIPT_FONT,HORIZ_DIR,2);
outtextxy(x+100,y+30,"a");
outtextxy(x+110,y+30," ");
outtextxy(x+120,y+30,"p");
outtextxy(x+130,y+30,"r");
outtextxy(x+140,y+30,"o");
outtextxy(x+150,y+30,"d");
outtextxy(x+160,y+30,"u");
outtextxy(x+170,y+30,"c");
outtextxy(x+180,y+30,"t");
outtextxy(x+190,y+30," ");
outtextxy(x+200,y+30,"o");
outtextxy(x+210,y+30,"f");
outtextxy(x+220,y+30," ");
outtextxy(x+230,y+30,"a");
outtextxy(x+240,y+30,"d");
outtextxy(x+250,y+30,"i");
outtextxy(x+260,y+30,"a");
outtextxy(x+270,y+30,"n");
outtextxy(x+280,y+30,"t");
outtextxy(x+290,y+30,"u");
outtextxy(x+300,y+30,"m");
outtextxy(x+310,y+30," ");
outtextxy(x+320,y+30,"g");
outtextxy(x+330,y+30,"r");
outtextxy(x+340,y+30,"o");
outtextxy(x+350,y+30,"u");
outtextxy(x+360,y+30,"p");
delay(700);
cleardevice();
}
void ball()
{
int i,j;
for(i=x-50,j=y+220;i<x,j>y+20;i+=2,j-=2)
{
setcolor(2);
setfillstyle(SOLID_FILL,2);
circle(i,j,10);
floodfill(i,j,2);
delay(50);
cleardevice();
}
}
void loading()
{
int i;
x=50;
y=250;
setcolor(6);
settextstyle(SCRIPT_FONT,HORIZ_DIR,2);
outtextxy(x+200,y-10,"L");
outtextxy(x+210,y-10,"o");
outtextxy(x+220,y-10,"a");
outtextxy(x+230,y-10,"d");
outtextxy(x+240,y-10,"i");
outtextxy(x+250,y-10,"n");
outtextxy(x+260,y-10,"g");
outtextxy(x+270,y-10,".");
outtextxy(x+280,y-10,".");
outtextxy(x+290,y-10,".");
for(i=0;i<=550;i+=10)
{
setcolor(15);
rectangle(x+i,y,x+i+10,y);
floodfill(x,y,15);
delay(80);
}
cleardevice();
}
void line_border()
{
int i;
printf("\n");
for(i=0;i<80;i++)
{
printf("*");
}
printf("\n");
}
void main_menu()
{
char ch;
clrscr();
line_border();
gotoxy(27,3);
printf("<<- THE BEE SHOOTER ->>");
gotoxy(10,9);
printf("* RULES OF THE GAME");
gotoxy(52,9);
printf("* ABOUT US");
gotoxy(10,11);
printf("* PLAY");
gotoxy(52,11);
printf("* HIGHSCORE");
gotoxy(10,13);
printf("* QUIT GAME");
gotoxy(1,20);
line_border();
printf("Enter your choice\t");
scanf("%c",&ch);
menu_option(ch);
}
void menu_option(char ch)
{
switch(ch)
{
case 'r':
case 'R':
	 rules();
	 break;
case 'a':
case 'A':
	 about();
	 break;
case 'p':
case 'P':
	 play();
	 break;
case 'h':
case 'H':
	 high_score();
	 break;
case 'q':
case 'Q':
	 exit(0);
default:main_menu();
}
main_menu();
}
void bee_random()
{
int x,y;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
x=rand()%getmaxx();
y=rand()%getmaxy();
setcolor(8);
ellipse(x,y,0,360,40,8);
setfillstyle(SOLID_FILL,6);
floodfill(x,y,8);
arc(x,y-8,0,180,20);
arc(x,y+8,180,0,20);
line(x-35,y-4,x-43,y-14);
line(x-35,y+4,x-43,y+14);
putpixel(x-31,y-2,15);
putpixel(x-31,y+2,15);
setcolor(4);
line(x-29,y,x+34,y);
delay(900);
cleardevice();
}
void creature1()
{
int x,y;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
x=rand()%getmaxx();
y=rand()%getmaxy();
setcolor(2);
setfillstyle(WIDE_DOT_FILL,2);
circle(x,y,20);                      //body
floodfill(x,y,2);
setcolor(5);
line(x+14,y-14,x+22,y-17);           //leg right top
line(x+22,y-17,x+28,y-14);
line(x-14,y-14,x-22,y-17);           //leg left top
line(x-22,y-17,x-28,y-14);
line(x+13,y+15,x+20,y+11);           //leg right bottom
line(x+20,y+11,x+25,y+14);
line(x-13,y+15,x-20,y+11);           //leg left bottom
line(x-20,y+11,x-25,y+14);
line(x+7,y-17,x+9,y-33);             //antena right
line(x-7,y-17,x-9,y-33);             //antena left
delay(600);
cleardevice();
}
void stone()
{
int x,y,i;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
x=rand()%getmaxx();
y=0;
for(i=y;i<=getmaxy();i+=10)
{
setcolor(7);
circle(x,y+i,10);
setfillstyle(SOLID_FILL,7);
floodfill(x,y+i,7);
delay(80);
cleardevice();
}
}
void cannon(int x,int y)
{
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cleardevice();
line(x+10,y-5,x+20,y-5);
line(x+10,y+5,x+20,y+5);
circle(x+20,y,5);
arc(x+10,y,90,270,5);
line(x+15,y-5,x+2,y-10);
line(x+15,y+5,x+2,y+10);
arc(x+2,y,90,270,10);
}
void option(int x,int y)
{
char ch;
ch=getch();
switch(ch)
{
case 'j':
case 'J':
	 down(x,y);
	 break;
case 'l':
case 'L':
	 up(x,y);
	 break;
case 'h':
case 'H':
	 hit(x,y);
	 break;
case 'e':
case 'E':
	 exit(0);
default:option(x,y);
}
}
void down(int x,int y)
{
int a;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cleardevice();
if(y<getmaxy())
{
a=y+10;
}
else
{
a=y;
}
cannon(x,a);
option(x,a);
}
void up(int x,int y)
{
int a;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cleardevice();
setcolor(10);
if(y>0)
{
a=y-10;
}
else
{
a=y;
}
cannon(x,a);
option(x,a);
}
void hit(int x,int y)
{
int i;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
for(i=0;i<getmaxx();i+=10)
{
cannon(x,y);
circle(x+i+20,y,6);
delay(100);
cleardevice();
}
main();
}
void high_score()
{
FILE *fp;
char ch;
int i,n,m,loc;
struct scorer s[3],ss;
clrscr();
fp=fopen("highscore.txt","w");
for(i=0;i<3;i++)
{
printf("Enter your name [space] score here\n");
scanf("%s",s[i].name);
scanf("%d",&s[i].score);
fwrite(&s[i],sizeof(struct scorer),1,fp);
clrscr();
}
fclose(fp);
fp=fopen("highscore.txt","r");
for(i=0;i<3;i++)
{
fread(&s[i],sizeof(struct scorer),1,fp);
printf("%d.  %s\t%d\n",i+1,s[i].name,s[i].score);
}
fclose(fp);
clrscr();
printf("enter the position you want to make change at\n");
scanf("%d",n);
//m=n-1;
loc= (int)n*sizeof(struct scorer);
fp=fopen("highscore.txt","w");
rewind(fp);
printf("Enter your name [space] score here\n");
scanf("%s",ss.name);
scanf("%d",ss.score);
fseek(fp,loc,0);
fwrite(&ss,sizeof(struct scorer),1,fp);
fclose(fp);
fp=fopen("highscore.txt","r");
for(i=0;i<3;i++)
{
fread(&s[i],sizeof(struct scorer),1,fp);
printf("%d.  %s\t%d\n",i+1,s[i].name,s[i].score);
}
fclose(fp);
}
void rules()
{
FILE *fp;
char *p,ch;
clrscr();
fp=fopen("rule.txt","r");
while((ch=getc(fp))!=EOF)
{
printf("%c",ch);
}
fclose(fp);
getch();
}
void about()
{
FILE *fp;
char ch;
clrscr();
fp=fopen("about.txt","r");
while((ch=getc(fp))!=EOF)
{
printf("%c",ch);
}
fclose(fp);
getch();
}
void play()
{
int i;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cleardevice();
for(i=0;i<=10;i++)
{
creature1();
stone();
}
getch();
}
