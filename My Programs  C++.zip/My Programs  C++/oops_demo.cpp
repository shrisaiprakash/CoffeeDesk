#include<iostream>
using namespace std;
class A
{
	private:
		int x;
	public:
		void input()
		{
			cout<<"Enter a number \t";
			cin>>x;
		}
		A comp()
		{
			if(x==100)
			return *this;
			else
			{
				cout<<"not eqyal to 100"<<endl;
				show();
			}
		}
		void show()
		{
			cout<<"number is "<<x<<endl;
		}
};
int main()
{
	class A a;
	a.input();
	A b;
	b=a.comp();
	b.show();
	return 0;
	
}

