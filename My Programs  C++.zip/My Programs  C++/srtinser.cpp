#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	char a[5][10],b[10];
	int i,j,k;
	printf("Enter five names\n");
	for(i=0;i<5;i++)
	{
		scanf("%s",&a[i]);
		strcpy(a[i],strlwr(a[i]));
	}
	//inser sort
	for(i=0;i<5;i++)
	{
		for(j=i+1;j<5;j++)
		{
			if(strcmpi(a[j],a[i])<=0)
			{
				strcpy(b,a[j]);
				for(k=j;k>i;k--)
				{
					strcpy(a[k],a[k-1]);
				}
				strcpy(a[k],b);
			}
		}
	}
	//printing sorted array
	for(i=0;i<5;i++)
	printf("%s\n",a[i]);
	return 0;
}
