#include<iostream>
using namespace std;

int main()
{
	int cin_;
	cout<<"Enter the value of cin\t";
	cin>>cin_;
	cout<<"value is "<<cin_<<endl;
}
