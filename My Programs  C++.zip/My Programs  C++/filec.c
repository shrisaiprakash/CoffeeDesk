#include<fstream>
using namespace std;
class student
{
	public:
		char name[20];
		char cl[10];
		int roll;
		int marks;
		float per;
};
int main()
{
	fstream file;
	class student s;
	file.open("student.txt",ios::out);
	cout<<"Enter name: "<<endl;
	gets(s.name);
	cout<<"Enter class: "<<endl;
	gets(s.cl);
	cout<<"Enter roll number: "<<endl;
	cin>>roll;
	cout<<"Enter marks: "<<endl;
	cin>>marks;
	per=(float)marks/5;
	file.write((char*) &s,sizeof(s));
	file.close();
	file.open("student.txt",ios::in);
	file.read((char*)&s,sizeof(s));
	cout<<"NAME: "<<name<<endl;
	cout<<"CLASS: "<<cl<<endl;
	cout<<"ROLL: "<<roll<<endl;
	cout<<"MAKRS: "<<marks<<endl;
	cout<<"PERCENTAGE: "<<per<<endl;
	file.close();
	return 0;
}
