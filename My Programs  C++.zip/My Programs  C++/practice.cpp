#include<iostream>
using namespace std;
class A
{
	int a;
	public:
		A(int a)
		{
			this->a=a;
		}
		A()
		{
		}
		friend A operator +(int x,A a4);
		void show()
		{
			cout<<"sum is "<<a<<endl;
		}
};
A operator +(int x, A a4)
{
	A a5;
	a5.a=x+a4.a;
	return  a5;
}
main()
{
	int x(10);
	class A aa(100);
	class A a1;
	a1=x+aa;
	a1.show();
}
