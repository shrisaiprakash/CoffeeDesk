#include<stdio.h>
#include<conio.h>
int main()
{
	int a[8],i,n,last;
	start:
	printf("enter the number of pertions seating first\n");
	scanf("%d",&n);
	if(n>=7)
	goto start;
	printf("enter the chair numbers\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the chair number for the last person comming late\n");
	scanf("%d",&last);
	printf("last comming person has to sit in the first place\n");
	//moving rest of the people
	for(i=n;i>0;i--)
	{
		a[i]=a[i-1];
	}
	a[i]=last;
	//persons arranged
	printf("new arrangement is \n");
	for(i=0;i<=n;i++)
	printf("%d\n",a[i]);
	return 0;
}
