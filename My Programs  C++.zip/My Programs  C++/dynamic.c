#include<stdio.h>
#include<conio.h>
#include<malloc.h>
int main()
{
	int *p,*i;
	int n,q;
	char ch;
	printf("enumbe of values u wanna enter\t");
	scanf("%d",&n);
	p=(int*)calloc(n,2);
	printf("%d at %u\n",*p,p);
	printf("%d at %u\n",*(p+1),(p+1));
	printf("%d at %u\n",*(p+2),(p+2));
printf("adderss stored in p is %u\n",p);
	for(i=p;i<p+n;i++)
	{
		printf("%u\n",i);
		scanf("%d",i);
	}
 printf("adderss stored in p is %u\n",p);
 i=p;
 printf("%d\n",*(i));
 printf("%d\n",*(i+1));
 printf("%d\n",*(i+2));
	for(i=p;i<(p+n);i++)
	{
		printf("%u\n",i);
		printf("%d\n",*i);
	}
	//free(p);
	printf("adderss stored in p is %u\n",p);
	printf("do you want to realloc size of array\n");
		printf("enter new size\t");
	
	ch=getchar();

	printf("hello");
	printf("hello");
	printf("hello");
	if(ch=='y')
	{
		printf("enter new size\t");
		scanf("%d",&q);
		p=(int*)realloc(p,q*sizeof(int));
	}
 	return 0;
}
