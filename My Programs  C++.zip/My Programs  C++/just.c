#include<iostream.h>
using namespace std;
void show(char = "hello!", int = 10);
int main()
{
	show();
	show("baby");
	return 0;
}
void show(char ch,int x)
{
	int i;
	for(i=0;i<x;i++)
	{
	   cout<<ch<<endl;
	}
}
