#include<conio.h>
#include<stdio.h>
void add(int ,int ,int*,int*);
int main()
{
	int a,b,s,d;
	printf("enter two numbers to be added\n");
	scanf("%d%d",&a,&b);
	add(a,b,&s,&d);
	printf("sum is = %d\n",s);
	printf("difference is = %d",d);
	return 0;
}
void add(int x,int y,int *p,int *q)
{
	*p=x+y;*q=x-y;
}
