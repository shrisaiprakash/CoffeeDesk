#include<stdio.h>
#include<conio.h>
int main()
{
	int i,j;
	for(i=0;i<12;i++)
	{
		if(i>=0&&i<=3)
		{
		   for(j=0;j<12;j++)
		   {
			if(j==0||j==1)
				printf(" ");
			else
				printf("*");
		   }
	    }
	    else if(i>=4&&i<=9)
	    {
		   for(j=0;j<12;j++)
		   {
			if(j==2||j==3)
			    printf("*");
			else
			    printf(" ");
		   }
	    }
	    else
	    {
		   for(j=0;j<12;j++)
		   {
			    printf("*");
		   }
	    }
	    printf("\n");
		}
	return 0;
}
