#include<stdio.h>
#include<conio.h>
int main()
{
	char *p,*q,*r;
	int c=0,i,j;
	printf("enter first string\n");
	scanf("%s",&p);
	printf("Enter second string\n");
	scanf("%s",&q);
	for(i=0;*(p+i)!='\n';i++)
	{
		c++;
	}
	printf("length of first string is %d",c);
	c=0;
	for(i=0;*(q+i)!='\0';i++)
	{
		c++;
	}
	printf("lenght of second string is %d",c);
	//concatination
	for(i=0;*(p+i)!='\0';i++)
	{
		*(r+i)=*(p+i);
	}
	*(r+i)=' ';
	for(j=0;*(q+j)!='\0';j++)
	{
		*(r+i+1+j)=*(q+j);
	}
	*(r+i+1+j+1)=' ';
	printf("concatinated string is %s\n",r);
	return 0;
}
