#include<stdio.h>
#include<conio.h>
int bino(int,int);
void main()
{
	int n,r,b;
	printf("Enter value of n\t");
	scanf("%d",&n);
	printf("Enter value of r\t");
	scanf("%d",&r);
	b=bino(n,r);
	printf("Final value is %d",b);
}
int bino(int n,int r)
{
	if(n==0||r==0)
	return 1;
	else
	return bino(n-1,r-1)+bino(n-1,r);
}
