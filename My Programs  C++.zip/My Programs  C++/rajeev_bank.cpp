#include<stdio.h>
#include<fstream>
#include<iostream>
using namespace std;
class Bank
{
	public:
	int deposite;
	int acn;
	char name[50];
	char act[50];
	int balence;
	
		void account_open();
		void debit();
		void display();
};
void Bank::account_open()
{
	cout<<"\nenter your name:";
	cin>>name;
	cout<<"\nenter your account number:";
	cin>>acn;
	cout<<"\nenter account type:";
	cin>>act;
	cout<<"\nenter initial deposite amount (100-200)";
	cin>>balence;
}
void Bank::display()
{
    cout<<"NAME:\t"<<name<<endl;
	cout<<"A/c No.:\t"<<acn<<endl;
	cout<<"BALANCE:\t"<<balence<<endl;
	cout<<"A/c Type:\t"<<act<<endl<<endl;
}

void Bank::debit()
{
	int amount;
	cout<<"Enter deposite amount:\t";
	cin>>amount;
	deposite+=amount;
}

int main()
{
	Bank obj[10];
	int i,c,acc_no;
	char ch;
	fstream file;
	
	do{
		cout<<"\npress 1 for open account:";
		cout<<"\npress 2 for Balence inquary:";
		cout<<"\npress 3 for deposite:";
		cout<<"\nenter your choice:";
		cin>>c;
		switch(c)
		{
			case 1:
	         file.open("bank_file1.txt",ios::out|ios::app|ios::binary);
	         for(int i=0;i<2;i++)
	         {
		       obj[i].account_open();
		       file.write((char*)&obj[i],sizeof(obj[i]));
	           }
	            cout<<endl<<"Successfully created"<<endl;
	            file.close();
	            break;
	        case 2:
	        cout<<"\nenter your account number:";
	        cin>>acc_no;
	        file.open("bank_file1.txt",ios::in);
	        for(i=0;i<2;i++)
	        {
	        	  file.read((char*)&obj[i],sizeof(obj[i]));
	        	if(acc_no==obj[i].acn)
                 {
	           
	        		obj[i].display();
				}
			}
			file.close();
			break;
			
			case 3:
			cout<<"Enter the account number for deposite:]\t";
	        cin>>acc_no;
	          file.open("bank_file1.txt",ios::in|ios::app|ios::binary);
	         for(i=0;i<2;i++)
	         {
		       file.read((char*)&obj[i],sizeof(obj[i]));
		        if(acc_no==obj[i].acn)
		          {
		          	
		            	obj[i].debit();
			            //int m=sizeof(obj[i])*i;
			            file.seekg(0,ios::end);
			            file.write((char*)&obj[i],sizeof(obj[i]));
			            cout<<"Updated Account Details are:"<<endl;
		//	file.read((char*)&b1[i],sizeof(b1[i]));
		//	b1[i].display();
		            }
	           	}
	
	           	file.close();
	           	break;
			default:
				cout<<"\nentered wrong choice:";
			}
			cout<<"\nenter y for continue else n:";
			cin>>ch;
		
	}while(ch=='y' ||ch=='Y');
	return 0;
}
