#include<stdio.h>
#include<conio.h>
int main()
{
	int i,j;
	for(i=0;i<9;i++)
	{
		if(i==0||i==8)
		{
			for(j=0;j<30;j++)
			{
				if(j>=0&&j<10||j>=20&&j<30)
				printf("*");
				else if(j>=10&&j<20)
				printf(" ");
			}
		}
		else if(i>=1&&i<=3)
		{
			for(j=0;j<30;j++)
			{
				if(j==0||j==9||j==20||j==29)
				printf("*");
				else
				printf(" ");
			}
		}
		else if(i==4)
		{
			for(j=0;j<30;j++)
			{
				if(j==0||j==9||j==20||j==29)
				printf("*");
				else if(j==10||j==11||j==19)
				printf(">");
				else if(j>=10&&j<20)
				printf("-");
				else
				printf(" ");
			}
		}

		else if(i>=5&&i<=7)
		{
			for(j=0;j<30;j++)
			{
				if(j==0||j==9||j==20||j==29)
				printf("*");
				else
				printf(" ");
			}
		}
		printf("\n");
	}
	getch();
	return 0;
}
