//towerr of hanio
#include<iostream>
using namespace std;
void hanoi(int n,char start,char mid,char end);
int main()
{
	char ch1='A',ch2='B',ch3='C';
	int n=3;
	hanoi(3,ch1,ch2,ch3);
	return 0;
}
void hanoi(int n,char start,char mid,char end)
{
	if(n!=0)
	{
		hanoi(n-1,start,end,mid);
		//hanoi(1,start,end,mid);
		cout<<"move "<<start<<" to "<<end<<endl;
		hanoi(n-1,mid,end,start);
	}
}


