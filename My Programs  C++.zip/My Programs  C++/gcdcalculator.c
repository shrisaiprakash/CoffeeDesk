#include<stdio.h>
#include<conio.h>
int gcd(int,int);
void swap(int*,int*);
int main()
{
	int  a,b,r,g=1;
	printf("enter two numbers\t");
	scanf("%d%d",&a,&b);
	if(a<0)
	a=-a;
	if(b<0)
	b=-b;
	if(a==0&&b==0)
	g=1;
	else if(a==0||b==0)
	{
		if(a>b)
		g=a;
		else
		g=b;
	}
	else
	g=gcd(a,b);
	printf("gcd is %d",g);
	return 0;
}
int gcd(int a ,int b)
{
	int r;
	if(a<b)
	swap(&a,&b);
	r=a%b;
	if(r!=0)
	return gcd(b,r);
	else if(r==0)
	return b;
	else
	return 1;
}
void swap(int *x,int *y)
{
	int t;
	t=*x;
	*x=*y;
	*y=t;
}
