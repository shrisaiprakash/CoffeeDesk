#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int queue[6],top=-1,del=-1;
void push()
{
	int n;
	if(top<5)
	{
		printf("Enter a number\n");
		scanf("%d",&n);
		queue[++top]=n;
	}
	else
	{
		printf("queue overflow\n");
	}
}
void pop()
{
	if(del<top)
	{
		printf("%d\n",queue[++del]);
	}
	else if(del==top)
	{
		printf("no element in queue\n");
	}
	else if(del==-1)
	{
		printf("queue underflow\n");
	}
}
void display()
{
	int i;
	if(del==top)
	{
		printf("empty queue\n");
	}
	else if(del==-1)
	{
		for(i=0;i<=top;i++)
		printf("%4d",queue[i]);
	}
	else
	{
		for(i=del;i<=top;i++)
		printf("%4d",queue[i]);
	}
}
void line()
{
	int i;
	printf("\n");
	for(i=0;i<115;i++)
	printf("*");
	printf("\n");
}
int option()
{
	int x;
	line();
	printf("1.insertion\n");
	printf("2.deletion\n");
	printf("3.display all\n");
	printf("4.exit\n");
	line();
	printf("Enter your choice\n");
	scanf("%d",&x);
	return x;
}
int main()
{
	int n;
	while(1)
	{
		n=option();
		switch(n)
		{
			case 1:push();break;
			case 2:pop();break;
			case 3:display();break;
			case 4:exit(0);
			default:printf("invalid choice\n");
		}
	}
	return 0;
}
