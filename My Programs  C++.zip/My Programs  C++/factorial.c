#include<stdio.h>
#include<conio.h>
int fact (int);
int main()
{
	int  a,b;
	printf("enter a number whose factorial you want to find\t\t");
	scanf("%d",&a);
	if(a>=0)
	{
	b=fact(a);
	printf("factorial of the entered number is\t%d",b);
    }
    else
    printf("invalid input");
	return 0;
}
int fact(int x)
{
	int f=1;
	if(x==0||x==1)
	return 1;
	else
	return (x*fact(x-1));
}
