#include<stdio.h>
#include<conio.h>
struct stud
{
	char name[20];
	int roll;
	void input()
{
	printf("Enter your name\t");
	scanf("%s",name);
	printf("Enter your roll\t");
	scanf("%d",&roll);
}
void output()
{
	printf("NAME= %s\tROLL= %d\n",name,roll);
}
	
};
typedef struct stud S;

int main()
{
	S s;
	s.input();
	s.output();
	return 0;
}
