/*----------------------------------------------HEADER FILES-------------------------------------------------------*/
#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<iomanip>
#include<string.h>
#include<stdio.h>
#include<dos.h>
#include<windows.h>
#include<fstream>
/*------------------------------------------PROTOTYPE DECLERATION------------------------------------------------*/
using namespace std;
float f_c,t_c,b_c;
void layout();
void options();
class your_trip;
/*---------------------------------------------DATE-----------------------------------------------------*/
class date
{
	int dd;
	int mm;
	int yy;
	public:
		void get_date()
		{
			cin>>dd>>mm>>yy;;
		}
		void show_date()
		{
			cout<<dd<<"-"<<mm<<"-"<<yy<<endl;
		}
};
/*------------------------------------------------FLIGHT---------------------------------------------------*/
class flight
{
	char name[20];
	char from[20];
	char to[20];
	char cls[10];
	class date d;
	int  adult;
	int  children;
	int  senior;
	float f_cost;
	public:
		void get_flight_info()
		{
			cout<<endl;
			cout<<"\t******************************FLIGHT****************************************"<<endl;
			cout<<"\t\t\tNAME:-\t";
			cin>>name;
			cout<<"\t\t\tFROM:-\t";
			cin>>from;
			Sleep(400);
			cout<<"\t\t\tTO:-\t";
			cin>>to;
			Sleep(400);
			cout<<"\t\t\tDATE OF JOURNEY:-[dd-mm-yyyy]\t";
			d.get_date();
			Sleep(400);
			cout<<"\t\t\tCLASS:-\t";
			cin>>cls;
			Sleep(400);
			cout<<"\t\t\tADULTS no. :-\t";
			cin>>adult;
			Sleep(400);
			cout<<"\t\t\tCHILDREN:-\t";
			cin>>children;
			Sleep(400);
			cout<<"\t\t\tSENIOR:-\t";
			cin>>senior;
			cout<<"\t*****************************************************************************"<<endl;
		}
		void show_flight_info()
		{
			system("CLS");
			cout<<"\t**********************************FLIGHT-DETAILS*************************************"<<endl;
			cout<<"\t\tNAME:-\t"<<name<<endl;
			cout<<"\t\tROUTE:-\t"<<from<<"->->->->->->->->->"<<to<<endl;
			cout<<"\t\tDATE OF JOURNEY:-\t";d.show_date();
			cout<<"\t\tADULT:-\t"<<adult<<endl;
			cout<<"\t\tCHILDREN:-\t"<<children<<endl;
			cout<<"\t\tSENIOR:-\t"<<senior<<endl;
			cout<<"\t\tTOTAL COST:-\t";cost_flight();
			cout<<"\t*******************************************************************************"<<endl;
			cout<<"Press [ENTER] continue...!!!";
		}
		void cost_flight()
		{
			f_cost=(float)(strcmpi(from,to));
			if(f_cost<0)
			f_cost=-f_cost;
			cout<<f_cost*999*(adult+children)<<endl;
			f_c=f_cost*999*(adult+children);
		}
		friend class your_trip;	
};
/*-----------------------------------------------------TRAIN---------------------------------------------------*/
class train
{
	char name[20];
	char from[20];
	char to[20];
	char cls[10];
	class date d;
	int  adult;
	int  children;
	int  senior;
	float t_cost;
	public:
		void get_train_info()
		{
			cout<<endl;
			cout<<"\t******************************TRAIN****************************************"<<endl;
			cout<<"\t\t\tNAME:-\t";
			cin>>name;
			cout<<"\t\t\tFROM:-\t";
			cin>>from;
			Sleep(400);
			cout<<"\t\t\tTO:-\t";
			cin>>to;
			Sleep(400);
			cout<<"\t\t\tDATE OF JOURNEY:-[dd-mm-yyyy]\t";
			d.get_date();
			Sleep(400);
			cout<<"\t\t\tCLASS:-\t";
			cin>>cls;
			Sleep(400);
			cout<<"\t\t\tADULTS no. :-\t";
			cin>>adult;
			Sleep(400);
			cout<<"\t\t\tCHILDREN:-\t";
			cin>>children;
			Sleep(400);
			cout<<"\t\t\tSENIOR:-\t";
			cin>>senior;
			cout<<"\t*****************************************************************************"<<endl;
		}
		void show_train_info()
		{
			system("CLS");
			cout<<"\t**********************************TRAIN-DETAILS*************************************"<<endl;
			cout<<"\t\tNAME:-\t"<<name<<endl;
			cout<<"\t\tROUTE:-\t"<<from<<"->->->->->->->->->"<<to<<endl;
			cout<<"\t\tDATE OF JOURNEY:-\t";d.show_date();
			cout<<"\t\tADULT:-\t"<<adult<<endl;
			cout<<"\t\tCHILDREN:-\t"<<children<<endl;
			cout<<"\t\tSENIOR:-\t"<<senior<<endl;
			cout<<"\t\tTOTAL COST:-\t";cost_train();
			cout<<"\t*******************************************************************************"<<endl;
			cout<<"Press [ENTER] continue...!!!";
		}
		void cost_train()
		{
			t_cost=(float)(strcmpi(from,to));
			if(t_cost<0)
			t_cost=-t_cost;
			cout<<t_cost*65*(adult+children)<<endl;
			t_c=t_cost*65*(adult+children);
		}
		friend class your_trip;
};
/*----------------------------------------------------BUS--------------------------------------------------------------*/
class bus
{
	char name[20];
	char from[20];
	char to[20];
	char cls[10];
	class date d;
	int  persons;
	float b_cost;
	public:
		void get_bus_info()
		{
			cout<<endl;
			cout<<"\t******************************BUS****************************************"<<endl;
			cout<<"\t\t\tNAME:-\t";
			cin>>name;
			cout<<"\t\t\tFROM:-\t";
			cin>>from;
			Sleep(400);
			cout<<"\t\t\tTO:-\t";
			cin>>to;
			Sleep(400);
			cout<<"\t\t\tDATE OF JOURNEY:-[dd-mm-yyyy]\t";
			d.get_date();
			Sleep(400);
			cout<<"\t\t\tCLASS:-\t";
			cin>>cls;
			Sleep(400);
			cout<<"\t\t\tNUMBER OF PERSONS :-\t";
			cin>>persons;
			cout<<"\t*****************************************************************************"<<endl;
		}
		void show_bus_info()
		{
			system("CLS");
			cout<<"\t**********************************BUS-DETAILS*************************************"<<endl;
			cout<<"\t\tNAME:-\t"<<name<<endl;
			cout<<"\t\tROUTE:-\t"<<from<<"->->->->->->->->->"<<to<<endl;
			cout<<"\t\tDATE OF JOURNEY:-\t";d.show_date();
			cout<<"\t\tPERSONS:-\t"<<persons<<endl;
			cout<<"\t\tTOTAL COST:-\t";cost_bus();
			cout<<"\t*******************************************************************************"<<endl;
			cout<<"Press [ENTER] continue...!!!";
		}
		void cost_bus()
		{
			b_cost=(float)(strcmpi(from,to));
			if(b_cost<0)
			b_cost=-b_cost;
			cout<<b_cost*12*persons<<endl;
			b_c=b_cost*12*persons;
		}
		friend class your_trip;
};
/*-------------------------------------------------YOUR - TRIP------------------------------------------------------*/
class your_trip
{
	flight f1;
	train t1;
	bus b1;
	public:
		void filght_trip()
		{
			fstream file;
			file.open("flight_info.txt",ios::in|ios::binary);
			file.read((char*)&f1,sizeof(f1));
			f1.show_flight_info();
			getch();
		}
		void train_trip()
		{
			fstream file;
			file.open("train_info.txt",ios::in|ios::binary);
			file.read((char*)&t1,sizeof(t1));
			t1.show_train_info();
			getch();
		}		
		void bus_trip()
		{
			fstream file;
			file.open("bus_info.txt",ios::in|ios::binary);
			file.read((char*)&b1,sizeof(b1));
			b1.show_bus_info();
			getch();
		}
		void trip_selector()
		{
			int x;
			cout<<"\t\t\t\tEnter your choice:\t";
			cin>>x;
			switch(x)
			{
				case 1:filght_trip();break;
				case 2:train_trip();break;;
				case 3:bus_trip();break;
				default:trip_option();
			}
		}
		void trip_option()
		{
			cout<<"\n\t\t1.FLIGHT TICKET"<<endl;
			cout<<"\t\t2.TRAIN TICKET"<<endl;
			cout<<"\t\t3.BUS TICKET"<<endl;
			trip_selector();
		}
};
/*----------------------------------------------------PAYMENT----------------------------------------------------*/
class payment
{
	char ch;
	char bank;
	char card_type;
	char card_no[10];
	char cvv[3];
	char username[15];
	char passwd[8];
	public:
		void f_pay()
		{
			cout<<"\n\n\t\t\tWanna Book !!! (say yes)\t"<<endl;
			ch=getch();
			if(ch=='y'||ch=='Y')
			{
				choice:
				cout<<"\t\t\tCREDIT CARD  or  NET BANKING"<<endl;
				bank=getch();
				if(bank=='c'||bank=='C')
				{
					cout<<"\t\t\tDEBIT CARD/CREDIT CARD/MASTER CARD"<<endl;
					card_type=getch();
					cout<<"\t\t\tCARD NUMBER[10]\t";
					cin>>card_no;
					cout<<"\t\t\tCVV CODE[3]\t";
					cin>>cvv;
					cout<<"\t\t\tAMOUNT\t"<<f_c<<endl;
					cout<<"\t\t\tConfirm Booking...!!![say yes]\t";
					ch=getch();
					if(ch=='y'||ch=='Y')
					{
						cout<<"\n\n\t\t(-:\tThank You\t:-)"<<endl;
						
					}
					else
					{
						cout<<"\n\n\t\t\tWish you a good day"<<endl;
					}
				}
				else if(bank=='n'||bank=='N')
				{
					cout<<"\t\t\tUSER NAME\t";
					cin>>username;
					cout<<"\t\t\tPASSWORD\t";
					cin>>passwd;
					cout<<"\t\t\tAMOUNT\t"<<f_c<<endl;
					cout<<"\t\t\tConfirm Booking...!!![say yes]\t";
					ch=getch();
					if(ch=='y'||ch=='Y')
					{
						cout<<"\n\t\t\t(-:\tThank You\t:-)"<<endl;
					}
					else
					{
						cout<<"\n\n\t\t\tWish you a good day"<<endl;
					}
				}
				else
				{
					goto choice;
				}
			}
			else
			{
				cout<<"\n\n\t\t\tWish you a good day"<<endl;
			}
			getch();
		}
		void t_pay()
		{
			cout<<"\n\n\t\t\tWanna Book !!! (say yes)\t"<<endl;
			ch=getch();
			if(ch=='y'||ch=='Y')
			{
				choice:
				cout<<"\t\t\tCREDIT CARD  or  NET BANKING"<<endl;
				bank=getch();
				if(bank=='c'||bank=='C')
				{
					cout<<"\t\t\tDEBIT CARD/CREDIT CARD/MASTER CARD"<<endl;
					card_type=getch();
					cout<<"\t\t\tCARD NUMBER[10]\t";
					cin>>card_no;
					cout<<"\t\t\tCVV CODE[3]\t";
					cin>>cvv;
					cout<<"\t\t\tAMOUNT\t"<<t_c<<endl;
					cout<<"\t\t\tConfirm Booking...!!![say yes]\t";
					ch=getch();
					if(ch=='y'||ch=='Y')
					{
						cout<<"\n\n\t\t(-:\tThank You\t:-)"<<endl;
						
					}
					else
					{
						cout<<"\n\n\t\t\tWish you a good day"<<endl;
					}
				}
				else if(bank=='n'||bank=='N')
				{
					cout<<"\t\t\tUSER NAME\t";
					cin>>username;
					cout<<"\t\t\tPASSWORD\t";
					cin>>passwd;
					cout<<"\t\t\tAMOUNT\t"<<t_c<<endl;
					cout<<"\t\t\tConfirm Booking...!!![say yes]\t";
					ch=getch();
					if(ch=='y'||ch=='Y')
					{
						cout<<"\n\t\t\t(-:\tThank You\t:-)"<<endl;
					}
					else
					{
						cout<<"\n\n\t\t\tWish you a good day"<<endl;
					}
				}
				else
				{
					goto choice;
				}
			}
			else
			{
				cout<<"\n\n\t\t\tWish you a good day"<<endl;
			}
			getch();
		}
		void b_pay()
		{
			cout<<"\n\n\t\t\tWanna Book !!! (say yes)\t"<<endl;
			ch=getch();
			if(ch=='y'||ch=='Y')
			{
				choice:
				cout<<"\t\t\tCREDIT CARD  or  NET BANKING"<<endl;
				bank=getch();
				if(bank=='c'||bank=='C')
				{
					cout<<"\t\t\tDEBIT CARD/CREDIT CARD/MASTER CARD"<<endl;
					card_type=getch();
					cout<<"\t\t\tCARD NUMBER[10]  ";
					cin>>card_no;
					cout<<"\t\t\tCVV CODE[3]\t";
					cin>>cvv;
					cout<<"\t\t\tAMOUNT\t"<<b_c<<endl;
					cout<<"\t\t\tConfirm Booking...!!![say yes]\t";
					ch=getch();
					if(ch=='y'||ch=='Y')
					{
						cout<<"\n\t\t\t(-:\tThank You\t:-)"<<endl;
						
					}
					else
					{
						cout<<"\n\n\t\t\tWish you a good day"<<endl;
					}
				}
				else if(bank=='n'||bank=='N')
				{
					cout<<"\t\t\tUSER NAME\t";
					cin>>username;
					cout<<"\t\t\tPASSWORD\t";
					cin>>passwd;
					cout<<"\t\t\tAMOUNT\t"<<b_c<<endl;
					cout<<"\t\t\tConfirm Booking...!!![say yes]\t";
					ch=getch();
					if(ch=='y'||ch=='Y')
					{
						cout<<"\n\n\t\t(-:\tThank You\t:-)"<<endl;
					}
					else
					{
						cout<<"\n\n\t\ttWish you a good day"<<endl;
					}
				}
				else
				{
					goto choice;
				}
			}
			else
			{
				cout<<"\n\n\t\t\tWish you a good day"<<endl;
			}
			getch();
		}
};
/*----------------------------------------------------MAIN FUNCTION-----------------------------------------------*/
int main()
{
	while(1)
	{
		layout();
		options();
	}	
}
/*----------------------------------------------------LAYOUT-----------------------------------------------------*/
void layout()
{
	system("CLS");
	cout<<"****************************************MAIN--MENU**********************************************"<<endl<<endl;
	Sleep(1000);
	cout<<"\t\t\t\t\tFLIGHT"<<endl<<endl;
	Sleep(1000);
	cout<<"\t\t\t\t\tTRAIN"<<endl<<endl;
	Sleep(1000);
	cout<<"\t\t\t\t\tBUS"<<endl<<endl;
	Sleep(1000);
	cout<<"\t\t\t\t\tYOUR TRIP"<<endl<<endl;
	Sleep(1000);
	cout<<"\t\t\t\t\tEXIT"<<endl<<endl;
	Sleep(1000);
	cout<<"************************************SELECT - YOUR - CHOICE*******************************************"<<endl;
}
/*---------------------------------------------------OPTIONS---------------------------------------------------*/
void options()
{
	flight ff;
	train tt;
	bus bb;
	your_trip yy;
	payment pp;
	char x;
	cout<<"Enter your choice:\t";
	x=getch();
	switch(x)
	{
		case 'f':
		case 'F':
			{
				ff.get_flight_info();
				ff.show_flight_info();
				fstream file;
				file.open("flight_info.txt",ios::out);
				file.write((char*)&ff,sizeof(ff));
				file.close();
				pp.f_pay();
				break;
			}
		case 't':
		case 'T':
			{
				tt.get_train_info();
				tt.show_train_info();
				fstream file;
				file.open("train_info.txt",ios::out);
				file.write((char*)&tt,sizeof(tt));
				file.close();
				pp.t_pay();
				break;
			}
		case 'b':
		case 'B':
			{
				bb.get_bus_info();
				bb.show_bus_info();
				fstream file;
				file.open("bus_info.txt",ios::out);
				file.write((char*)&bb,sizeof(bb));
				file.close();
				pp.b_pay();
				break;
			}
		case 'y':
		case 'Y':
			{
			 	yy.trip_option();
			 	break;		
			}	 		 
		case 'e':
		case 'E':
				cout<<"\n\t\t\t\t(-:\tThank you\t:-)";
				Sleep(5000);
				exit(0);
		default:options();
	}
}
/*-------------------------------------------------END OF PROGRAM----------------------------------------------------*/
