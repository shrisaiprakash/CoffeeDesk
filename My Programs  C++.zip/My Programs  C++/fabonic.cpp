#include<stdio.h>
#include<conio.h>
void fab(int,int);
int main()
{
	int a=0,b=1,s;
	fab(a,b);
	return 0;
}
void fab(int a,int b)
{
	b=a+b;
	if(a<100)
	{
		printf("%4d",a);
		return fab(b,a);
	}
}
//better method
#include<stdio.h>
#include<conio.h>
int fab(int a)
{
	if(a==0)
	return 0;
	else if(a==1)
	return 1;
	else
	return (fab(a-1)+fab(a-2));
}
int main()
{
	int a,i,j=0;
	printf("enter number\t");
	scanf("%d",&a);
	for(i=0;i<=a;i++)
	{
		printf("%4d",fab(j));
		j++;
	}
	return 0;
}
