#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct student
{
	char name[20];
	int id;
	struct student *link;
};
int main()
{
	char c;
	struct student *start,*new_std,*cur_std;
	while(1)
	{
	new_std=(struct student*)malloc(sizeof(struct student));	
	printf("Enter student name:\t");
	gets(new_std->name);
	printf("Enter student id:\t");
	scanf("%d",&new_std->id);
	new_std->link=NULL;
	if(start==NULL)
	{
		start=cur_std=new_std;
	}
	else
	{
		cur_std=new_std;
		cur_std->link=new_std;
	}
	printf("Do you want to exit type yes\n");
	scanf("%c",&c);
	if(c=='y'||c=='Y')
	break;
	else
	continue;
    }
	cur_std=start;
	while(cur_std!=NULL)
	{
	printf("NAME:\t%s\n",cur_std->name);
	printf("ID:\t%d",cur_std->id);
	cur_std=cur_std->link;
    }
	return 0;
}
