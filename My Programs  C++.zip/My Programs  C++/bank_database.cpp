#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;

class Bank
{
	public:
	char name[50]; 
    int ac;
	int balence;
	char act[100];
	void getdata();
	void disp();
	void deposite();
};

void Bank::getdata()
{
	cout<<"\n\t Enter account holder name:\n";
	cin>>name;
	cout<<"\n\tEnter account number:\n";
	cin>>ac;
	cout<<"\n\tEnter balence:\n";
	cin>>balence;
	cout<<"\n\tType of account:\n";
	cin>>act;
}
void Bank::disp()
{
	cout<<"\n\tAccount holder name=\t"<<name;
	cout<<"\n\tAccount Number=\t"<<ac;
	cout<<"\n\tBalence=\t"<<balence;
	cout<<"\n\tAccount Type=\t"<<act;
}
/*void bank::deposite()
{
	
}*/
int main()
{
	Bank obj[10];
	int i,uac,amount,f;
	fstream file;
	file.open("bank.txt", ios::out);
	for(i=0;i<2;i++)
	{
		obj[i].getdata();
		file.write((char *) & obj[i],sizeof(obj[i]));
	}
	file.close();
	file.seekg(0);
	
	Bank obj1[10];
	file.open("bank.txt",ios::in|ios::out);
	firse:
	cout<<"\nenter account number\n";
	cin>>uac;
	for(i=0;i<2;i++)
	{
		
		file.read((char *) & obj1[i],sizeof(obj1[i]));
		if(uac==obj[i].ac)
		{
			obj1[i].disp();
			cout<<"\n Enter the amount";
			cin>>amount;
	        obj1[i].balence=obj1[i].balence+amount;
	        file.write((char *) & obj[i],sizeof(obj[i]));	
		}
	//	obj1[i].disp();
	}
	file.close();
		cout<<"\n\t\t If You Want To Go To Home Then Press 1 Otherwise 0 : \n\t\t";
	cin>>f;
	if(f==1)
	{
		goto firse;
	}
	return 0;
}
