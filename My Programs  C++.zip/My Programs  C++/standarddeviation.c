#include<stdio.h>
#include<conio.h>
#include<math.h>
int a[10],b[10];
int sum=0,i,sumb=0;
float avg,var,std;
void stdcat();
int main()
{
	printf("enter ten numbers\n");
	stdcal();
	return 0;
}
void stdcal()
{
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		sum=sum+a[i];
	}
	avg=(float)sum/10;
	for(i=0;i<10;i++)
	{
		sumb=sumb+pow((avg-a[i]),2);
	}
	var=(float)sumb/10;
	std=sqrt(var);
	printf("sum of all elements is = %d.00\n",sum);
	printf("variant of all elements is = %.2f\n",var);
	printf("standard deviation is = %.2f\n",std);

}
