#include<stdio.h>
#include<conio.h>
int main()
{
	//binary searching
	int a[5];
	int b,l,m,i,x;
	printf("enter five numbers\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter the number to be searched\t");
	scanf("%d",&x);
	b=0;l=4;
	for(i=0;b!=l;i++)
	{
		m=(b+l)/2;
		if(x==a[m])
		printf("number found");
		else if(x>a[m])
		{
			b=m+1;
		}
		else if(x<a[m])
		{
			l=m-1;
		}
	}
	return 0;
}
