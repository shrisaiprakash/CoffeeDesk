#include<iostream>
#include<fstream>
using namespace std;
class student
{
	protected:
		char name[20];
		int rn;
	public:
		void getdata()
		{
			cout<<"enter name:"; cin>>name;
			cout<<"enter roll number:"; cin>>rn;
		}
		void showdata()
		{
			cout<<"NAME: "<<name<<endl;
			cout<<"ROLL NO.: "<<rn<<endl;
		}
};
int main()
{
	class student s;
	fstream file;
	int i;
	file.open("result.dat",ios::out);
	cout<<"enter data\n";
	for(i=0;i<5;i++)
	{
		s.getdata();
		file.write((char*)&s,sizeof(s));
	}
	file.close();
	file.open("restul.dat",ios::in);
	file.seekg(0,ios::end);
	int len=file.tellg();
	int n=len/sizeof(s);
	int m;
	cout<<"total number of students are\t"<<n<<endl;
	cout<<"Enter number of student whose record you want to check:\t";
	cin>>m;
	int pos=m-1;
	file.seekg(pos);
	file.read((char*)&s,sizeof(s));
	s.showdata();
	file.close();
	return 0;
}
