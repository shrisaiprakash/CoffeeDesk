#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<malloc.h>
struct node
{
	int data;
	struct node *link;
};
typedef struct node NODE;
NODE *start,*top,*temp;
void insert()
{
	temp=(NODE*)malloc(sizeof(NODE));
	if(temp==NULL)
	{
		printf("No memory allocated\n");
	}
	else
	{
		printf("Enter a number\t");
		scanf("%d",&temp->data);
		temp->link=NULL;
		if(start==NULL)
		{
			start=top=temp;
		}
		else
		{
			top->link=temp;
			top=temp;
		}
	}
}
void del_queue()
{
	if(start==NULL)
	{
		printf("Queue is empty\n");
	}
	else
	{
		printf("data is %d\n",start->data);
		start=start->link;
	}
}
int option()
{
	int choice;
	printf("**********MENU***************\n");
	printf("1.insert\n2.delete\n3.exit\n");
	printf("*****************************\n");
	printf("Enter your choice\t");
	scanf("%d",&choice);
	return choice;
}
void selector(int x)
{
	switch(x)
	{
		case 1:insert();break;
		case 2:del_queue();break;
		case 3:exit(0);
		default:printf("Invalid input\n");
	}
}
main()
{
	int a;
	while(1)
	{
		a=option();
		selector(a);
	}
	return 0;
}
