#include<stdio.h>
#include<conio.h>
int main()
{
	int i,j,a=10,k=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<a;j++)
		{
			printf(" ");
		}
		for(j=0;j<(2*i+1);j++)
		{
			if(j<=i)
			printf("%2d",++k);
			else
			printf("%2d",--k);
		}
		a-=2;
		printf("\n");
	}
	return 0;
}
