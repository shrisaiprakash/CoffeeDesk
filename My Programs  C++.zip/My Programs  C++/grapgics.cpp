#include<stdio.h>
#include<stdlib.h>
#include<iostream>

int main()
{
	int d,r;
	char *b,c;
	b=gcvt(3.141234546789098765,12,&c);
	printf("pi=%c.%s",b[0],b+1);
	std::cout<<std::endl<<c<<std::endl;
	//std::cout<<r<<std::endl;
}
