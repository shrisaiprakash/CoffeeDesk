//circular linked list
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
};
typedef struct node NODE;
NODE *start,*next,*current,*previous;
void create()
{
	next=(NODE*)malloc(sizeof(NODE));
	if(next==NULL)
	{
		printf("not enough space\n");
	}
	else
	{
		printf("Enter an element\t");
		scanf("%d",&next->data);
		if(start==NULL)
		{
			start=current=next;
			next->link=start;
		}
		else
		{
			current->link=next;
			current=next;
			current->link=start;
		}
	}
}
void display()
{
	current=start;
	do
	{
		printf("%d-->",current->data);
		current=current->link;
	}while(current!=start);
	printf("NULL\n");
}
int options()
{
	int choice;
	printf("******************\n");
	printf("1.insert\n");
	printf("2.display\n");
	printf("3.exit\n");
	printf("******************\n");
	printf("Enter your choice\t");
	scanf("%d",&choice);
	return choice;
}
void selector(int x)
{
	switch(x)
	{
		case 1:create();break;
		case 2:display();break;
		case 3:exit(0);
		default :printf("invalid choice\n");
	}
}
int main()
{
	int a;
	while(1)
	{
		a=options();
		selector(a);
	}
	return 0;
}
