#include<stdio.h>
#include<conio.h>
#include<malloc.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
};
typedef struct node NODE;
NODE *start,*next,*current;
void insert();
void front_delete();
void end_delete();
void display_link();
int option();
void selector(int );
int main()
{
	int x;
	while(1)
	{
		x=option();
		selector(x);
	}
	return 0;
}
void insert()
{
	next=(NODE*)malloc(sizeof(NODE));
	if(next==NULL)
	{
		printf("No memory allocated");
	}
	else
	{
		printf("enter the number:\t");
		scanf("%d",&next->data);
		next->link=NULL;
		if(start==NULL)
		{
			start=current=next;
		}
		else 
		{
			current->link=next;
			current=next;
		}
	}
}
void front_delete()
{
	if(start==NULL)
	{
		printf("The linked list is empty");
	}
	else
	{
		start=next->link;
	}
}
void end_delete()
{
	NODE *previous;
	current=start;
	
	while(current!=NULL)
	{
		if(current->link!=NULL)
		{
			previous->link=current;
			current=current->link;
		}
		else
		{
			current=current->link;
		}
	}
	previous->link=NULL;
}
void display_link()
{
	current=start;
	while(current!=NULL)
	{
		printf("DATA is %d\n",current->data);
		current=current->link;
	}
}
int option()
{
	int a;
	printf("***************************************************************\n");
	printf("1.Insert into the link\n");
	printf("2.Delete from front of list\n");
	printf("3.Delete from end of list\n");
	printf("4.Display list\n");
	printf("5.Exit\n");
	printf("***************************************************************\n");
    printf("Enter your choice:\t");
    scanf("%d",&a);
    return a;
}  
void selector(int x)
{
	switch(x)
	{
		case 1:insert();break;
		case 2:front_delete();break;
		case 3:end_delete();break;
		case 4:display_link();break;
		case 5:exit(0);
		default : printf("invalid input\n");
	}
}
