#include<iostream>
using namespace std;
class A
{
	int count;
	public:
		A()
		{
			count=0;
		}
		A(int x)
		{
			count = x;
		}
		void operator++()
		{
			count+=1;
		}
		void operator++(int )
		{
			count+=1;
		}
		void operator--()
		{
			count-=1;
		}
		int show()
		{
			return count;
		}
	//	friend ostream & operator <<(ostream & out,A & A);
};

int main()
{
	A a1;
	A a2(10);
	a1++;
	//cout<<a1<<endl;
	cout<<a1.show()<<endl;
	++a1;
	//cout<<a1<<endl;
	cout<<a1.show()<<endl;
	a2++;
	//cout<<a2<<endl;  //able to represent like a primitive data type
	cout<<a2.show()<<endl;
	++a2;
	//cout<<a2<<endl;
	cout<<a2.show();
	return 0;
}
