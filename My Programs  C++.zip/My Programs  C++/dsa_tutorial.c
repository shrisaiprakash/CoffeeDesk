#include<stdio.h>
#include<conio.h>
char a[10];
char stack[10];
int top=-1;
char pop()
{
	if(top!=-1)
	{
		if(stack[top--]=='+'||stack[top--]=='-')
		return 1;
		else if (stack[top--]=='*'||stack[top--]=='/')
		return 2;
	}
}
int main()
{
	int i;
	printf("Enter the expression in infix form\n");
	gets(a);
	for(i=0;i<strlen(a);i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		printf("%c",a[i]);
		else if (a[i]=='+'||a[i]=='-')
		pop();
	}
}

