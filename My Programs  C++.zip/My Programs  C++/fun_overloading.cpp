#include<iostream>
#include<conio.h>
using namespace std;
class sum
{
	int a;
	int b;
	float c;
	float d;
	public:
		void add(int a,int b)
		{
          cout<<"sum is  "<<(a+b);
		}
		void add(float c,float d)
		{
		 cout<<"sum is  "<<(c+d);
		}
	    sum(int x)
		{
			cout<<"enter first integer number\t";
			cin>>a;
			cout<<"enter second integer nunber\t";
			cin>>b;
			add(a,b);
		}
		sum(float x)
		{
			cout<<"enter first real number\t";
			cin>>c;
			cout<<"enter second real nunber\t";
			cin>>d;
			add(c,d);
		}
};
int main()
{
   char ch;
   cout<<"if you want to calculate sum of integers press i"<<endl<<"if you want to calculate sum of real numbers press r "<<endl;
   cout<<"All other characters will be considered invalid"<<endl;
   beg:
   	cin>>ch;
   	if(ch=='i'||ch=='I')
   	class sum s(1);
	else if(ch=='r'||ch=='R')
	class sum s(4.0F);
	else
	goto beg;
	return 0;
}
