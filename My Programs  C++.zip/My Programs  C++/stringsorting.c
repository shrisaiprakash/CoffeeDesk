#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	char a[5][10],temp[10];
	int i,j;
	printf("enter five names of max 10 characters\n");
	for(i=0;i<5;i++)
	{
		gets(a[i]);
		toupper(a[i]);
	}
	for(i=0;i<4;i++)
	{
		for(j=i+1;j<5;j++)
		{
			if(strcmp(a[j],a[i])<0)
		{
			strcpy(temp,a[i]);
			strcpy(a[i],a[j]);
			strcpy(a[j],temp);
		}

		}
	}
	for(i=0;i<5;i++)
	{
		puts(a[i]);
		printf("\n");
	}
	return 0;
}
