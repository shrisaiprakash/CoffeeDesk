#include<iostream>
#include<fstream>
using namespace std;
class student
{
	protected:
		char name[20];
		int roll;
	public:
		void input()
		{
			cout<<"Enter name:";
			cin>>name;
			cout<<"Enter roll:";
			cin>>roll;
		}
		void show()
		{
			cout<<"name: "<<name<<endl;
			cout<<"roll: "<<roll<<endl;
		}
};
int main()
{
	class student s;
	fstream file;
	int i;
	file.open("std.dat",ios::out);
	for(i=0;i<3;i++)
	{
	s.input();
	file.write((char*)&s,sizeof(s));
    }
	file.close();
	file.open("std.dat",ios::in|ios::binary);
	while(file.eof()==0)
	{
		file.read((char*)&s,sizeof(s));
		s.show();
	}
	file.seekg(0,ios::end);
	int len=file.tellg();
	int n=len/sizeof(s);
	int m;
	cout<<"number of records available are:\t"<<n<<endl;
	cout<<"enter the student number whose record you wab=nt to see:\t";
	cin>>m;
	m=(m-1)*sizeof(s);
	file.seekp(m);
	file.read((char*)&s,sizeof(s));
	s.show();
	file.close();
	return 0;
}
