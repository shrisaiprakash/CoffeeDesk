#include<stdio.h>
#include<conio.h>
int main()
{
	int a[5];
	int i,j,c=0,b=1,t;
	printf("enter five elements\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=c;i<5;i++)
	{
		for(j=b;j<5;j++)
		{
			if(a[j]<a[i])
			{
				t=a[i];
				a[i]=a[j];
				a[j]=t;
			}
		}
		b++;
		c++;
	}
	for(i=0;i<5;i++)
	printf("%4d\n",a[i]);
printf("\n");
for(i=4;i>=0;i--)
printf("%4d\n",a[i]);

	return 0;
}
