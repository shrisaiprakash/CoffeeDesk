#include<stdio.h>
#include<conio.h>
#include<string.h>
void input();
struct customer
{
	char ac0[14];
	char name[20];
	float balance;
	char pin[4];
}c[5];
int main()
{
	//struct customer c[5];
	char ac1[14];
	char ac2[14];
	float am;
	char pass[4];
	int i,b,r;
	char ch;
	input();
	do
	{
		printf("enter your account number\t");
        ac1:
		gets(ac1);
		for(i=0;i<5;i++)
		{
			b=strcmp(ac1,c[i].ac0);
			if(b==0)
			{
				r=i;
				break;
            }
		}
		if(b!=0)
		goto ac1;
		printf("enter destination account number\t");
	    ac2:
		gets(ac2);
			for(i=0;i<5;i++)
			{
				b=strcmp(ac2,c[i].ac0);
				if(b==0)
				break;
			}
			if(b!=0)
			goto ac2;
		printf("enter the amount to be trasfered\t");
    	am:
		scanf("%f",&am);
				if(c[r].balance<am)
				{
					goto am;
				}
		printf("enter your pin\t");
		pass:
		gets(pass);
		if(strcmp(c[r].pin,pass)!=0)
		goto pass;
		printf("your transection is successful\n");
		printf("do you want to make another transection, if so press y\n");
		ch=getchar();
	}while(ch!='y'||ch!='Y');
	return 0;
}
void input()
{
	int j,l;
	printf("enter bank detail of each customer\n");
	for(j=0;j<5;j++)
	{
		printf("Name\t");
		name:
		gets(c[j].name);
		if(strcmp(c[j].name,"\0")==0)
		goto name;
		acc:
		printf("Account number\t");
		gets(c[j].ac0);
		if(strlen(c[j].ac0)!=14)
		goto acc;
		printf("Balance\t");
		scanf("%f",&c[j].balance);
		printf("Your PIN\t");
		pin:
		gets(c[j].pin);
		if(strlen(c[j].pin)!=4)
		goto pin;
	}
}
