/1/linked list
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
struct node
{
	int data;
	struct node *link;
};
typedef struct node NODE;
NODE *start,*next,*current,*previous;
void create()
{
	next=(NODE*)malloc(sizeof(NODE));
	if(next==NULL)
	{
		printf("not enough space\n");
	}
	else
	{
		printf("Enter an element\t");
		scanf("%d",&next->data);
		next->link=NULL;
		if(start==NULL)
		{
			start=current=next;
		}
		else
		{
			current->link=next;
			current=next;
		}
	}
}
void display()
{
	current=start;
	while(current!=NULL)
	{
		printf("%d-->",current->data);
		current=current->link;
	}
	printf("NULL\n");
}
void front_ins()
{
	next=(NODE*)malloc(sizeof(NODE));
	if(next==NULL)
	{
		printf("not enough space\n");
	}
	else
	{
		printf("Enter an element\t");
		scanf("%d",&next->data);
		next->link=start;
		start=next;
	}
}
void end_ins()
{
	next=(NODE*)malloc(sizeof(NODE));
	if(next==NULL)
	{
		printf("not enough space\n");
	}
	else
	{
		printf("Enter an element\t");
		scanf("%d",&next->data);
		next->link=NULL;
		current=start;
		while(current->link!=NULL)
		{
			current=current->link;
		}
		current->link=next;
	}
}
void mid_ins()
{
	int data;
	printf("Enter the data before which you want to insert\t");
	scanf("%d",&data);
	next=(NODE*)malloc(sizeof(NODE));
	if(next==NULL)
	{
		printf("not enough space\n");
	}
	else
	{
		printf("Enter en element\t");
		scanf("%d",&next->data);
		current=start;
		while(current->data!=data)
		{
			if(current->data!=data)
			{
				previous=current;
				current=current->link;
			}
			else
			{
				current=current->link;
			}
		}
		next->link=current;
		previous->link=next;
	}
}
void front_del()
{
	if(start==NULL)
	{
		printf("Empty linked list\n");
	}
	else
	{
		start=start->link;
	}
}
void mid_del()
{
	int data;
	printf("Enter the element you want to delete\t");
	scanf("%d",&data);
	current=start;
	while(current->data!=data)
	{
		if(current->data!=data)
		{
			previous=current;
			current=current->link;
		}
		else
		{
			current=current->link;
		}
	}
	previous->link=current->link;
}
void end_del()
{
	current=start;
	while(current->link!=NULL)
	{
		previous=current;
		current=current->link;
	}
	previous->link=NULL;
}
int options()
{
	int choice;
	printf("***************\n");
	printf("1.create a new node\n");
	printf("2.display the linked list\n");
	printf("3.insert at the beginning\n");
	printf("4.insert in the middle\n");
	printf("5.insert at the end\n");
	printf("6.delete from front\n");
	printf("7.delete in the middle\n");
	printf("8.delete at the end\n");
	printf("9.exit\n");
	printf("******************\n");
	printf("Enter your choice\t");
0	scanf("%d",&choice);
	return choice;
}
void selector(int x)
{
	switch(x)
	{
		case 1:create();break;
		case 2:display();break;
		case 3:front_ins();break;
		case 4:mid_ins();break;
		case 5:end_ins();break;
		case 6:front_del();break;
		case 7:mid_del();break;
		case 8:end_del();break;
		case 9:exit(0);
		default:printf("invalid input\n");
	}
}
int main()
{
	int a;
	while(1)
	{
		a=options();
		selector(a);
	}
	return 0;
}
