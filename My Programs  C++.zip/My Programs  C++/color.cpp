//macro of function
#include<iostream>
#define (a+b) add(a,b)
template <class T>
void add(T &a,T &b)
{
	cout<<"sum is "<<a+b<<endl;
}
int option()
{
	int choice;
	cout<<"************menu****************"<<endl;
	cout<<"1.integer addition"<<endl;
	cout<<"2.float addition"<<endl;
	cout<<"3.exit"<<endl;
	cout<<"********************************"<<endl;
	cout<<"Enter your choice"<<endl;
	cin>>choice;
	return choice;
}
void selector(int x)
{
	int i1,i2;
	float f1,f2;
	switch(x)
	{
		case 1:
			cout<<"Enter two integers";
			cin>>i1>>i2;
			<int>(i1+i2);
		case 2:
			cout<<"Enter two floating numbers";
			cin>>f1>>f2;
			<float>(f1+f2);
	}
}
int main()
{
	int a;
	while(1)
	{
		a=option();
		selector(a);
		return 0;
	}
}
