#include <stdio.h>
	#include <conio.h> 
	struct stack
	{
		int low, high;
	}; 
	void main()
	{
		int a[50];
		int n;
		//clrscr();
		printf("\nEnter n: ");
		scanf("%d",&n);
		read_data(a,n);
		a[n]=9999;
		printf("\nBefore sort :");
		print_data(a,n);
		qck_srt(a,n);
    printf("\nAfter sort :");
	    print_data(a,n);
	}
	int read_data(int a[],int max)
{
		int i;
		printf("\nEnter %d values \n",max);
	for(i=0; i < max; i++)
		{
			scanf("%d",&a[i]);
		}
		return;
	}
	int print_data(int a[],int max)
{
		int i;
		for(i=0; i < max; i++)
		{
			printf("%4d",a[i]);
		}
		return;
	}
	int qck_srt(int a[], int n)
	{
		struct stack s[50];
		int top;
int i, j, k, l, h;
		int t;
		//... Initialize Stack
		top = -1;
		//... Push First Position
		top++;
		s[top].low = 0;
		s[top].high = n - 1;
		//... While Stack is not Empty do the following
		while( top != -1 )
		{
			//... Pop top Partition
			l = s[top].low;
			h = s[top].high;
			top--;
			if(l >= h )
			{
				continue;
	        }
			k = a[l];
			i = l;
			j = h + 1;
			while( i < j )
			{
				while( i < h && a[i] <= k )
				{
					i++;
				}
				while( j > l && a[j] >= k )
				{
					j--;
				}
				if( i < j )
				{
					t = a[i];
				a[i] = a[j];
					a[j] = t;
				} // if
			} // while
			if(l != j)
			{
				t = a[l];
				a[l] = a[j];
				a[j] = t;
			} // if
			//... Push Right Partition
			top++;
			s[top].low = j + 1;
			s[top].high = h;
			//... Push Left Partition
			top++;
			s[top].low = l;
			s[top].high = j - 1;
		} // while
		return;
	} // qck_srt

