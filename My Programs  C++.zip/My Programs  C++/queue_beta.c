// circular queue

//header file inclusion
#include<stdio.h>
#include<stdlib.h>
int queue[5],i,beg=-1,end=-1,size=5;
void ins_num();
void del_num();
void display();
int options();
void selector(int);
int main()
{
	int a;
	while(1)
	{
		a=options();
		selector(a);
	}return 0;
}
void ins_num()
{
	if(end==beg+1)
	{
		printf("circular queue overflow\n");
	}
	else
	{
		beg=(beg+1)%size;
		printf("Enter an element\t");
		scanf("%d",&queue[beg]);
	}
}
void del_num()
{
	if(beg==end+1)
	{
		printf("circluar queue is underflow\n");
	}
	else
	{
		end=(end+1)/size;
		printf("%4d",queue[end--]);
	}
}
void display()
{
	int i;
	for(i=end;i<=beg;i++)
	{
		printf("%4d",queue[i]);
	}
}
int options()
{
	int choice;
	printf("**********************************\n");
	printf("1.insert a number\n");
	printf("2.dlete a number\n");
	printf("3.display circular queue\n");
	printf("4.exit\n");
	printf("**********************************\n");
	printf("Enter your choice\t");
	scanf("%d",&choice);
	return  choice;
}
void selector(int x)
{
	switch(x)
	{
		case 1:ins_num();break;
		case 2:del_num();break;
		case 3:display();break;
		case 4:exit(0);
		default:printf("invalid input\n");
	}
}
