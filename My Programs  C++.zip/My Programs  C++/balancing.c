//balancing factor
#include<stdio.h>
#include<conio.h>
char stack[10];
int top=-1;
void push(char c)
{
	stack[++top]=c;
	//printf("%c",stack[top]);
}
char pop()
{
	//printf("%c",stack[top]);
	return stack[top--];
}
int main()
{
	char *x,y;
	char a[10];
	int p=0;
	printf("Enter the expresion\n");
	scanf("%s",a);
	x=a;
	while(*x!='\0')
	{
		//printf("hi\n");
		if(*x=='['||*x=='{'||*x=='(')
		{
			//printf("%c",*x);
			push(*x);
		}
		else if(*x==')')
		{
			y=pop();
			if(y!='(')
			{
				p=1;
				printf("%d+0\n",p);
				break;
			}
			else
			{
				x++;
				continue;
			}
		}
		else if(*x=='}')
		{
			y=pop();
			if(y!='{')
			{
				p=1;
				printf("%d+1\n",p);
				break;
			}
			else{
				x++;
				continue;
			}
		}
		else if(*x==']')
		{
			y=pop();
			if(y!=']')
			{
				p=1;
				printf("%d+2\n",p);
				break;
			}
			else
			{
				x++;
				continue;
			}
		}
	}
	if(top==-1)
	{
		printf("no error\n");
	}
	else 
	printf("error\n");
	return 0;
}
