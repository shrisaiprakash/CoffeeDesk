#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int cq[5],max=5,top=-1,del=-1;
void insert()
{
	int n;
	if(del==(top+1))
	    printf("overflow\n");
	else
	{
		if(del==-1)
		del=top=0;
		else
		top=(top+1)%max;
		printf("Enter a number:\t");
		scanf("%d",&n);
		cq[top]=n;
	}
}
void deletion()
{
	int n;
	if(del==-1)
	   printf("underflow\n");
	else
	{
		n=cq[del];
		if(top==del)
		del=top=-1;
		else
		del=(del+1)%max;
		printf("%d\n",n);
		
	}
}
int main()
{
	int x;
	while(1)
	{
		printf("1.enter\n2.pop\n3.exit\n");
		printf("enter your choice\n");
		scanf("%d",&x);
		switch(x)
		{
			case 1:insert();break;
			case 2:deletion();break;
			case 3:exit(0);
			default:printf("invaid\n");
		}
	}
	return 0;
}
