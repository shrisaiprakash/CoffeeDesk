#include<stdio.h>
#include<conio.h>
int main()
{
	int a[2][3][3]={ {
	                 {100,200,300},
					 {100,200,300},
					 {100,200,300}
					 },
	                 {
					 {400,500,600},
					 {400,500,600},
					 {400,500,600}
					 }
					};
	int i,j,k;
	for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		{
			if(j==1)
			printf("%4d",i+1);
			printf("\t");
			for(k=0;k<3;k++)
			{
				printf("%5d",a[i][j][k]);
			}
			printf("\n\n");
		}
		printf("\n\n");
	}
	return 0;
	               
}
