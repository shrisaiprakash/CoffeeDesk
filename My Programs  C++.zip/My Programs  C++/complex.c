#include<iostream>
#include<conio.h>
using namespace std;
class complex
{
	int real;
	int img;
  public:
  	complex()
  	{ }
  	void input()
  	{
  		cout<<"enter the real part\t";
  		cin>>real;
  		cout<<"enter the imaginary part\t";
  		cin>>img;
    }
    void  output(complex c1,complex c2)
    {
    	int c3;
    	c3=c1.real+c2.real;
    	cout<<c3;
    	cout<<"+i";
    	c3=c1.img+c2.img;
        cout<<c3;
    }
    ~complex()
    {}
};
int main()
{
	class complex c1,c2;
	c1.input();
	c2.input();
	complex c3;
	c3.output(c1,c2);
	return 0;
}
