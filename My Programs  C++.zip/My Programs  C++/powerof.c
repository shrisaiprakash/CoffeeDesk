#include<stdio.h>
#include<conio.h>
#include<math.h>
int main()
{
	//r=y^n;
	float r=1,y;
	int n,i=1;
	printf("enter the number\t");
	scanf("%f",&y);
	printf("enter its exponents\t");
	scanf("%i",&n);
	while(i<=n)
	{
		r=y*r;
		i++;
	}
	printf("\nresult is %f\n",r);
	return 0;
	
}
