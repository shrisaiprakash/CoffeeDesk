#include<iostream>
#include<math.h>
using namespace std;
class rec
{
	private:
		float x;
		float y;
	public:
		rec(float xco,float yco)
		{
			x=xco;
			y=yco;
		}
		void showrec()
		{
			cout<<"X="<<(float)x<<endl;
			cout<<"Y="<<(float)y<<endl;
		}
		rec()
		{
			x=y=0;
		}
};
class polar
{
	private:
		float rd;
		float ang;
	public:
		operator rec()
		{
			float xco=rd*cos(ang);
			float yco=rd*sin(ang);
			return rec(xco,yco);
		}
		void showp()
		{
			cout<<"polar coordinates are\t"<<endl;
			cout<<rd<<":"<<ang<<endl;
		}
		void input()
		{
			cout<<"Enter radians :\t";
			cin>>rd;
			cout<<"Enter angle :\t";
			cin>>ang;
		}
};
int main()
{
	class polar p;
	class rec r;
	p.input();
	r=p;
	r.showrec();
	p.showp();
}
