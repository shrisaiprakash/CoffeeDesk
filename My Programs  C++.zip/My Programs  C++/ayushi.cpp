#include<iostream>
#include<conio.h>
using namespace std;
//creating first class called base class
class base
{
	public:
		base()                                           //default constructor creation
		{
			cout<<"Default constructor of base class"<<endl;
		}
		base(int x)                                     //parameterised constructor creation
		{
			cout<<"Parameterised constructor of base class"<<endl;
		}
};
//creation of second class called child class to inherit base class
class child:public base                         //publically inheriting base class into child class
{
	public:
		child():base(1)                             // default constructor of child class
		{
			cout<<"default contructor of child class"<<endl;
		}
};
// main function 
int main()
{
	child c;
	base::base(1);
	return 0;
}

