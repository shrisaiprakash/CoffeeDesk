#include<iostream>
using namespace std;
class A
{
	int x;
	char name[20];
	public:
		void in()
		{
			cout<<"Enter the value for x "; 
			cin>>x;
			cout<<"Enter the user name ";
			cin>>name;
		}
		void out()
		{
			cout<<"Value of x is "<<x<<endl;
			cout<<"User name is "<<name<<endl;
		}
};
int main()
{
	A a1;
	a1.in();
	A a2(a1);
	a2.out();
	return 0;
}
