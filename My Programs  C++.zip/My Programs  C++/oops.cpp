#include<stdio.h>
#include<conio.h>
#include<malloc.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *nxt;
};
struct node *start,*new_node,*current;
int main()
{
	char c;
	start=NULL;
	while(1)
	{
		new_node=(struct node*)malloc(sizeof(struct node));
		printf("Enter data\t");
		scanf("%d",&new_node->data);
		//new_node->nxt=NULL;
		if(start==NULL)
		{
			start=current=new_node;
		}
		else
		{
			current=new_node;
			current->nxt=new_node;
		}
		printf("wanna coutinue say yes orelse no\t");
		scanf("%c",&c);
		if(c=='y'||c=='Y')
		continue;
		else
		break;
	}
	new_node->nxt=NULL;
	current=start;
	while(current!=NULL)
	{
		printf("%d-->>",current->data);
		current=current->nxt;
	}
	printf("NULL\n");
	return 0;
}
