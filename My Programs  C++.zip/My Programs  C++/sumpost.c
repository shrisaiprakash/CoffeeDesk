//postfix calculation
#include<stdio.h>
#include<conio.h>
int stack[10];
int top=-1;
void push(char c)
{
	stack[++top]=(int)(c-48);	
}
int pop()
{
	return stack[top--];
} 
void cal(char c)
{
	int d;
	int a=pop();
	int b=pop();
	switch(c)
	{
		case '+':d=b+a;break;
		case '-':d=b-a;break;
		case '*':d=b*a;break;
		case '/':d=b/a;break;
	}
	stack[++top]=d;
	printf("%d",d);
}
int main()
{
	char a[10],c;
	int i;
	printf("Enter the expression\n");
	scanf("%s",a);
	printf("%s\n",a);
	while((c=a[i])!='\n')
	{
		if(c=='+'||c=='-'||c=='*'||c=='/')
		cal(c);
		else 
		push(c);
		i++;
	}
	printf("%d",pop());
	return 0;
}
