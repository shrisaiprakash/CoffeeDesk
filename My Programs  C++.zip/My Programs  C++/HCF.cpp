#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int a,b,r;
	cout<<"enter two nubmers\t";
	cin>>a>>b;
	if(a<0)
	a=-a;
	if(b<0)
	b=-b;
	if(a>b)
	{
	for(r=b;r>0;r--)
	{
		if(a%r==0&&b%r==0)
		{
		cout<<"hcf is "<<r<<endl;
		break;
		}
	}
    }
    else
    {
    	for(r=b;r>0;r--)
	{
		if(a%r==0&&b%r==0)
		{
		cout<<"hcf is "<<r<<endl;
		break;
		}
	}
	}
	return 0;
}
