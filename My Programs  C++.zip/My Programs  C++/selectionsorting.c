#include<stdio.h>
#include<conio.h>
#include<string.h>
void swap(int a[],int ,int);
int min_finder(int a[],int start,int end)
{
	int i,min;
	min=start;
	for(i=start+1;i<end;i++)
	{
		if(a[i]<a[min])
		min=i;
	}
	return min;
}
void sel_sort(int a[],int end)
{
	int i;
	for(i=0;i<end-1;i++)
	{
	swap(a,i,min_finder(a,i,end));
    }
}
void swap(int a[],int i,int j)
{
	int t;
	t=a[i];
	a[i]=a[j];
	a[j]=t;
}
int main()
{
	int a[5],i;
	printf("enter five numbers\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	sel_sort(a,5);
	printf("\nAscending order\n");
	for(i=0;i<5;i++)
	{
		printf("\n%d",a[i]);
	}
	printf("\nDescending order\n");
	for(i=4;i>=0;i--)
	{
		printf("\n%d",a[i]);
	}
	return 0;
}
