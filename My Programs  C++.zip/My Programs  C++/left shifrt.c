//left shift
#include<stdio.h>
#include<conio.h>
int main()
{
	int a[5],i,k;
	printf("enter five number\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	k=a[i];
	for(i=0;i<4;i++)
	{
		a[i]=a[i+1];
	}
	a[i]=k;
	for(i=0;i<5;i++)
	{
		printf("%d\n",a[i]);
	}
	return 0;
}
