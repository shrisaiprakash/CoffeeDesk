#include<iostream>
using namespace std;
int main()
{
	int (*p)();
	cout<<"i love bhargavi\t";
	p=main;
	(*p)();
}
