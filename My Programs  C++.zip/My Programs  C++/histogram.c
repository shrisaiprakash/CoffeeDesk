#include<stdio.h>
#include<conio.h>
int main()
{
	int n[5];
	int  i,j,k;
	for(i=0;i<5;i++)
	{
		printf("enter the number of employees in group %d\t",i+1);
		scanf("%d",&n[i]);
	}
	for(i=0;i<5;i++)
	{
		for(k=0;k<3;k++)
		{
			if(k==1)
			{
				printf("group %d",i+1);
			for(j=0;j<n[i];j++)
			{
				printf("*");
			}
			printf("(%d)",n[i]);
			}
			else
			{
				printf("       ");
		    	for(j=0;j<n[i];j++)
			    {
				   printf("*");
			    }
		   }
			printf("\n");
		}
		printf("\n");
	}
   return 0;
}
