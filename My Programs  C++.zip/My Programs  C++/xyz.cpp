//templets of class and functions
#include<iostream>
using namespace std;
templete <class T>
class add
{
	private:
		T a,b;
	public:
		void get()
		{
			cout<<"enter two numbers:\n";
			cin>>a>>b;
		}
		T sum()
		{
			T c;
			c=a+b;
			return (c);
		}
};
int main()
{
	class add <int> i;
	class add <float> f;
	i.get();
	f.get();
	i.sum();
	f.sum();
	return 0;
}
