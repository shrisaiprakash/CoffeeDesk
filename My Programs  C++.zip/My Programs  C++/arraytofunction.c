#include<stdio.h>
#include<conio.h>
void great(int* b,int );
int i;
int main()
{
	int a[5];
	int *p;
	printf("enter five nubmers\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	//greatest number
	p=a;
	great(p,5);
	return 0;
}
void great(int* b,int x)
{
	int max;
	max=*b;
	for(i=1;i<x;i++)
	{
		if(*(b+i)>max)
		{
			max=*(b+i);
		}
	}
	printf("greatest number is =% d",max);
}
