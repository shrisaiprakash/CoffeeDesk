#include<stdio.h>
#include<conio.h>
#include<ctype.h>
#include<string.h>
char stack[10];
int top=-1;
void push(char c)
{	
	stack[++top]=c;
}
char pop()
{
	return stack[top--];
}
int priority(char c)
{
	if(c=='+'||c=='-')
	return 1;
	else if(c=='*'||c=='/')
	return 2;
}
int main()
{
    char   a[10];
	char  *x,y;
	int i;
	printf("Enter the expression\n");
	scanf("%s",a);
	printf("%s\n",a);
	x=a;
	while(*x!='\0')
	{
		//printf("hi\n");
		if(isalnum(*x))
		{
			printf("%c",*x);
			//x++;
		}
		else if(*x=='('||*x==')')
		{
			x++;
			continue;
		}
		else
		{ 
		while(priority(stack[top])>=priority(*x))
		printf("%c",pop());
	    }
		push(*x);
		x++;
	}
	while(top>-1)
	printf("%c",pop());
	return 0;
}
