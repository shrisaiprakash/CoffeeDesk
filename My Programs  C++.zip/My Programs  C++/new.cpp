#include<iostream>
using namespace std;
char *nplz();
char *cplz();
main()
{
	char *p;
	{
		char name[]="pakki";
		p=name;
	}
	cout<<"i love my country";
	cout<<p;
}
