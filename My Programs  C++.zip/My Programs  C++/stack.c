#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int stack[5];top=-1;
void push()
{
	int n;
	if(top<5)
	{
		printf("enter the element to be inserted\n");
		scanf("%d",&n);
		stack[++top]=n;
	}
	else
	{
		printf("stack overflow\n");
	}
}
void pop()
{
	if(top>-1)
	{
		printf("%d\n",stack[top--]);
	}
	else
	{
		printf("stack underflow\n");
	}
}
void display()
{
	int i;
	if(top==-1)
	{
		printf("stack empty\n");
	}
	else
	{
		for(i=0;i<=top;i++)
		printf("%4d",stack[i]);
	}
}
int option()
{
	int x;
	printf("\n***********************************************************************\n");
	printf("1.insert\n");
	printf("2.show\n");
	printf("3.display\n");
	printf("4.exit\n");
	printf("***********************************************************************\n");
	printf("enter your choice\n");
	scanf("%d",&x);
	return x;
}
int main()
{
	int n;
	while(1)
	{
		n=option();
		switch(n)
		{
			case 1:push();break;
			case 2:pop();break;
			case 3:display();break;
			case 4:exit(0);
			default:printf("invalid choice\n");
		}
	}
	return 0;
}
