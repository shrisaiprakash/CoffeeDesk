#include<stdio.h>
#include<conio.h>
int main()
{
	int a[5],i,j,t;
	printf("enter five numbers\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	//bubble sorting
	for(i=4;i>0;i--)
	{
		for(j=0;j<i;j++)
		{
			if(a[j+1]<a[j])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=a[j];
			}
		}
	}
	for(i=0;i<5;i++)
	{
		printf("%4d\n",a[i]);
	}
	return 0;
}
