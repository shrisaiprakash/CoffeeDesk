#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int queue[6],top=-1,del=-1,i;
void push()
{
	int x;
	if(top<5)
	{
		if(top<=del)
		{
			printf("Enter a number:\t");
		    scanf("%d",&x);
	    	queue[++top]=x;
		}
		else
		{
			printf("overflow\n");
		}
	}
	else if(top==5)
	{
		top=-1;
		if(top==del)
		{
			printf("overflow\n");
		}
		else
		{
			printf("Enter a number:\t");
		    scanf("%d",&x);
	    	queue[++top]=x;
		}
    }
}
void pop()
{
	if(top<del)
	{
		printf("%4d\n",queue[++del]);
	}
	else if(del==5)
	{
		del=-1;
		printf("%4d\n",queue[++del]);
	}
	else if(del<top) 
	{
		printf("%4d\n",queue[++del]);
	}
	else
	{
		printf("underflow\n");
	}
}
void display()
{
	if(del==-1&&del<top)
	{
		for(i=0;i<=top;i++)
		{
			printf("%4d",queue[i]);
		}
	}
	else if(top<del)
	{
		for(i=del;i<=5;i++)
		printf("%4d",queue[i]);
		for(i=0;i<=top;i++)
		printf("%4d",queue[i]);
	}
	else if(del==top)
	{
		printf("empty queue\n");
	}
}
void line()
{
	printf("\n");
	for(i=0;i<118;i++)
	printf("*");
	printf("\n");
}
int option()
{
	int x;
	line();
	printf("1.insertion\n");
	printf("2.deletion\n");
	printf("3.dispaly all\n");
	printf("4.exit\n");
	line();
	printf("Enter your choice\n");
	scanf("%d",&x);
	return x;
}
int main()
{
	int n;
	while(1)
	{
		n=option();
		switch(n)
		{
			case 1:push();break;
			case 2:pop();break;
			case 3:display();break;
			case 4:exit(0);
			default:printf("inva;id choice\n");
		}
	}
	return 0;
}
