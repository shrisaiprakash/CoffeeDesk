#include<iostream>
#include<fstream>
#include<stdio.h>
using namespace std;
class detail
{
	char name[20];
	int id;
	float salary;
	public:
		void input()
		{
			cout<<"Enter your name\t";
			gets(name);
			cout<<"Enter your ID\t";
			cin>>id;
			cout<<"Enter your monthly salary\t";
			cin>>salary;
		}
		void output()
		{
			cout<<"NAME:\t"<<name<<endl;
			cout<<"ID:\t"<<id<<endl;
			cout<<"SALARY:\t"<<salary<<endl;
		}
};
int main()
{
	detail d1;
	d1.input();
	fstream file;
	file.open("test_file.txt",ios::out);
	file.write((char*)&d1,sizeof(d1));
	file.close();
	file.open("test_file.txt",ios::binary|ios::in);
	detail d2;
	file.read((char*)&d2,sizeof(d2));
	d2.output();
	return 0;
}
