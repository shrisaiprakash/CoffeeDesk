/*file for updating a content*/
#include<fstream>
#include<iostream>
#include<Conio.h>
using namespace std;
class student
{
	private:
		char name[20];
		int roll;
	public:
		void get()
		{
			cout<<"enter name:";
			cin>>name;
			cout<<"enter roll:";
			cin>>roll;
		}
		
		void output()
		{
			cout<<"NAME: "<<name<<endl;
			cout<<"ROLL: "<<roll<<endl;
		}
};
int main()
{
	class student std;
	fstream file;
	int i;
	file.open("std.dat",ios::out|ios::app);
	for(i=0;i<3;i++)
	{
	std.get();
	file.read((char*)&std,sizeof(std));
    }
    file.close();
    file.open("std.dat",ios::in|ios::out|ios::app|ios::binary);
    while(file.eof()==0)
    {
    	file.read((char*)&std,sizeof(std));
    	std.output();
	}
	file.clear();
	cout<<"enter a new record"<<endl;
	std.get();
	file.write((char*)&std,sizeof(std));
	file.seekg(0,ios::beg);
	while(file.eof()==0)
	{
		file.read((char*)&std,sizeof(std));
		std.output();
	}
	int len=file.tellg();
	int n=len/sizeof(std);
	cout<<"Number of records existing in file are "<<n<<endl;
	cout<<"Total length of file is "<<len<<endl;
	cout<<"enter the number of record you want to update ";
	int m;
	cin>>m;
	int loc=(m-1)*sizeof(std);
	file.seekp(loc);
	std.get();
	file.write((char*)&std,sizeof(std));
	file.seekg(0,ios::beg);
	cout<<"updated file is"<<endl;
	while(!(file.eof()))
	{
		file.read((char*)&std,sizeof(std));
		std.output();
	}
	file.close();
	return 0;
}
