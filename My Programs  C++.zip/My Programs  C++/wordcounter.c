#include<stdio.h>
#include<conio.h>
#include<string.h>
int main()
{
	char line[100];
	int word=0,i;
	printf("enter a line and to end press enter key\n");
	gets(line);
	puts(line);
	 i=0;
	 while(line[i]!='\0')
	{
		if(line[i]==' ')
		{
			word++;
}
	   i++;
	}
	printf("number of words entered is %d",++word);
	//printf("characterss entered are %d",ch);
	return 0;
}
