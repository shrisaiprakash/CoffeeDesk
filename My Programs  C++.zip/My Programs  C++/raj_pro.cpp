#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<fstream>
using namespace std;
class bank
{
	public:
		char name[50]; 
		int ac;
		int balance;
		char act[100];
		void getdata();
		void display();
		void deposite();
};
void bank::getdata()
{
	cout<<"Enter your name:\t";
	cin>>name;
	cout<<"Enter account number:\t";
	cin>>ac;
	cout<<"Enter balance:\t";
	cin>>balance;
	cout<<"Enter account type:\t";
	cin>>act;
}
void bank::display()
{
	cout<<"NAME:\t"<<name<<endl;
	cout<<"A/c No.:\t"<<ac<<endl;
	cout<<"BALANCE:\t"<<balance<<endl;
	cout<<"A/c Type:\t"<<act<<endl<<endl;
}
void bank::deposite()
{
	int amount;
	cout<<"Enter deposite amount:\t";
	cin>>amount;
	balance+=amount;
}
int main()
{
	int acc_no;
	bank b1[2],b2;
	fstream file;
	file.open("bank_file.txt",ios::out|ios::in|ios::binary);
	for(int i=0;i<2;i++)
	{
		b1[i].getdata();
		file.write((char*)&b1[i],sizeof(b1[i]));
	}
	cout<<endl<<"Successful"<<endl;
	cout<<"Enter the account number for deposite:]\t";
	cin>>acc_no;
	for(int i=0;i<acc_no;i++)
	{
		file.read((char*)&b1[i],sizeof(b1[i]));
		if(acc_no==b1[i].ac)
		{
			b1[i].deposite();
			int m=sizeof(b1[i])*i;
			file.seekg(-m,ios::end);
			file.write((char*)&b1[i],sizeof(b1[i]));
			cout<<"Updated Account Details are:"<<endl;
			file.read((char*)&b1[i],sizeof(b1[i]));
			b1[i].display();
		}
	}
	return 0;
}
