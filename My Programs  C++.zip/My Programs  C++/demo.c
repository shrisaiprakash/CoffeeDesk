#include<iostream>
#include<conio.h>
void show(char = "hello!",int = 10);
int main()
{
	show();
	show(baby);
	show(darling,50);
}
