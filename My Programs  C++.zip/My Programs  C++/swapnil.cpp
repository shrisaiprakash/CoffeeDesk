#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<fstream>
using namespace std;
int seats_available;
class time;
class route;
class BOOK;
class time
{
	int hr;
	int min;
	public:
		void get_time()
		{
			cin>>hr>>min;
		}
		void show_time()
		{
			cout<<hr<<" : "<<min<<endl;
		}
};
class route
{
	char start_from[15];
	char reach_at[15];
	public:
		void get_bus_route()
		{
			cin>>start_from>>reach_at;
		}
		void show_bus_route()
		{
			cout<<start_from<<"-------->>"<<reach_at<<endl;
		}
};
class BOOK
{
	char std_name[20];
	char pick_up[10];
	char drop[10];
	public:
		static void seat_file()
		{
			ofstream fout("seat.available1.txt");
		    for(int i=1;i<=50;i++)
			{
				fout<<i<<" ";
			}
		}
		void seat_file_out()
		{
			int ch;
			ifstream fin("seat.available1.txt");
			for(int i=1;i<=50;i++)
			{
				fin>>ch;
				cout<<ch<<" ";
			}
		}
		void seat_file_rebuild()
		{
			ofstream fout("seat.available1.txt");
			for(int i=1;i<=50;i++)
			{
				if(i==seat_choice)
				{
					fout<<"  "; 
				}
				else
				{
					fout<<i<<" ";
				}
			}
		}
		void booking_now()
		{
			int ch;
			cout<<"Enter your name:\t";
			cin>>std_name;
			cout<<"Enter your pick up point:\t";
			cin>>pick_up;
			cout<<"Enter your drop point:\t";
			cin>>drop;
			cout<<"Available seats are:\n";
			seat_file_out();
			cout<<endl;
			choice_seat:
			cout<<"Enter your choice of seat number:\t";
			cin>>seat_choice;
			seat_file_rebuild();
	    }
		void booked()
		{
			cout<<"STUDENT NAME:\t"<<std_name<<endl;
			cout<<"PICK UP:\t"<<pick_up<<endl;
			cout<<"DROP:\t"<<drop<<endl;
			cout<<"SEAT NUMBER:\t"<<seat_choice<<endl;
		}
	protected:
	int seat_choice;
};

class BUS:public time,route,BOOK
{
	private:
		static int count_bus;
		static int seats_in_bus;
		char my_seat[5];
		char bus_name[15];
		char bus_driver_name[20];
		char seat_choice[5];
		char std_name[20];
		char pick_up[10];
		char drop[10];
		public:
			BUS()
			{
				++count_bus;
			}
			void get_bus_info()
			{
				cout<<"Enter the name of the BUS:\t";
				cin>>bus_name;
				cout<<"Enter the name of BUS DRIVER:\t";
				cin>>bus_driver_name;
				cout<<"Enter bus timings [ hours -- minutes ]:\t";
				get_time();
				cout<<"Enter the ROUTE of the bus [start -- end ]:\t";
				get_bus_route();
			}
			void show_bus_info()
			{
				cout<<"********************************************************"<<endl<<endl;
		    	cout<<"\t\tBUS NAME --> "<<bus_name<<endl;
		    	cout<<"\t\tBUS NUMBER --> "<<count_bus<<endl;
		    	cout<<"\t\tBUS DRIVER -->  "<<bus_driver_name<<endl;
		    	cout<<"\t\tTOTAL SEATS -->  "<<seats_in_bus<<endl;
		    	cout<<"\t\tSEATS AVAILABLE --> "<<seats_available<<endl;
		    	cout<<"\t\tBUS TIMINGS -->  ";show_time();
		    	cout<<"\t\tBUS ROUTE -->  ";show_bus_route();
		    	cout<<"*********************************************************"<<endl<<endl;
			}		
			       
			void i_am_booking()
			{
				booking_now();
			    booked();
			}
};
int BUS::seats_in_bus=50;
int BUS::count_bus=0;
void option()
{
	cout<<"*******************************\n";
	cout<<"1.get"<<endl;
	cout<<"2.show"<<endl;
	cout<<"3.book"<<endl;
	cout<<"4.exit"<<endl;
	cout<<"**********************************\n";
}
int main()
{
	int x;
	BUS b;
	while(1)
	{
		option();
		cout<<"Enter your choice\t";
		cin>>x;
		switch(x)
		{
			case 1:b.get_bus_info();
			       break;
			case 2:b.show_bus_info();
			       break;
			case 3:b.i_am_booking();
			       break;
			case 4:exit(0);
			default:cout<<"invalid choice";
		}
	}
	return 0;
}

