#include<iostream>
using namespace std;
template<class T>
void swap(T &a,T &b)
{
	T c;
	c=a;
	a=b;
	b=c;
}
int main()
{
	char a,b;
	int x,y;
	float f1,f2;
	cout<<"Enter two characters\t";
	cin>>a>>b;
	swap(&a,&b);
	cout<<"characters after swap\t"<<a<<" "<<b<<endl;
	cout<<"Enter two integers\t";
	cin>>x>>y;
	swap(&x,&y);
	cout<<"Integers after swap\t"<<x<<" "<<y<<endl;
	cout<<"Enter two floating numbers\t";
	cin>>f1>>f2;
	swap(&f1,&f2);
	cout<<"Floating numbers after swap\t"<<f1<<" "<<f2<<endl;
}
