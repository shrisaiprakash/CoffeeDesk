package com.example.shriprakash.justjava;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void decreaseQuantity(View v){
        TextView quantity = (TextView) findViewById(R.id.coffeeQuantity);
        int value = Integer.parseInt(quantity.getText().toString());
        if(value>0){
            value -= 1;
        }else{
            value = value;
        }
        quantity.setText(""+value);
    }

    public void increaseQuantity(View v){
        TextView quantity = (TextView) findViewById(R.id.coffeeQuantity);
        int value = Integer.parseInt(quantity.getText().toString());
        value += 1;
        quantity.setText(""+value);
    }

    public void submitOrder(View view){
        orderSummary(priceCalculator());
    }

    private boolean checkWhippedCream(){
        CheckBox whippedCream = (CheckBox) findViewById(R.id.WhippedCream);
        return whippedCream.isChecked();
    }

    private boolean checkChocolate(){
        CheckBox chocolate = (CheckBox) findViewById(R.id.Chocolate);
        return chocolate.isChecked();
    }

    private int coffeeQuantity(){
        TextView coffeeQuantity = (TextView) findViewById(R.id.coffeeQuantity);
        return Integer.parseInt(coffeeQuantity.getText().toString());
    }


    private String customerName(){
        EditText customerName = (EditText) findViewById(R.id.CustomerName);
        return customerName.getText().toString();
    }

    public String toppingSelected(){
        String temp ="None";
        if(checkWhippedCream()){
            if(temp == "None"){
                temp = "Whipped Cream";
            }else{
                temp += ", Whipped Cream";
            }
        }
        if(checkChocolate()){
            if(temp == "None"){
                temp = "Chocolate";
            }else{
                temp += ", Chocolate";
            }
        }

        return temp;
    }

    private double priceCalculator(){
        double price = 10.0;
        if(checkChocolate()){
            price += 3.0;
        }
        if(checkWhippedCream()){
            price += 2.0;
        }
        return price;
    }
    public void orderSummary(double price){
        String temp = toppingSelected();
        int coffeeMugs = coffeeQuantity();
        String name = customerName();
        if(name.equals("")){
            name = "None";
        }
        String summary = "" + getString(R.string.name, name);
        summary += "\n" + getString(R.string.toppings_ordered,temp);
        summary += "\n" + getString(R.string.quantity_show,coffeeMugs);
        summary += "\n" + "Price : "+(price*coffeeMugs);
        summary += "\n"+getString(R.string.thank_you);
        TextView orderSummary = (TextView) findViewById(R.id.orderSummary);
        orderSummary.setText(summary);
        Intent intentMail = new Intent(Intent.ACTION_SEND);
        intentMail.setData(Uri.parse("mailto:"));
        intentMail.setType("text/html");
        intentMail.putExtra(Intent.EXTRA_EMAIL, "shrisaiprakash99@gmail.com");
        intentMail.putExtra(Intent.EXTRA_SUBJECT, "Coffee Desk Order");
        intentMail.putExtra(Intent.EXTRA_TEXT,summary);
        startActivity(intentMail);

    }
}
