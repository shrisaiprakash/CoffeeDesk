package com.example.shriprakash.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView scoreKeeperA = (TextView) findViewById(R.id.scoreKeeperA);
        scoreKeeperA.setText("0");
        TextView scoreKeeperB = (TextView) findViewById(R.id.scoreKeeperB);
        scoreKeeperB.setText("0");
    }

    public void addOneA(View view){
        TextView scoreKeeper = (TextView) findViewById(R.id.scoreKeeperA);
        int temp = Integer.parseInt(scoreKeeper.getText().toString());
        temp += 1;
        scoreKeeper.setText(""+temp);
    }

    public void addTwoA(View view){
        TextView scoreKeeper = (TextView) findViewById(R.id.scoreKeeperA);
        int temp = Integer.parseInt(scoreKeeper.getText().toString());
        temp += 2;
        scoreKeeper.setText(""+temp);
    }

    public void addThreeA(View view){
        TextView scoreKeeper = (TextView) findViewById(R.id.scoreKeeperA);
        int temp = Integer.parseInt(scoreKeeper.getText().toString());
        temp += 3;
        scoreKeeper.setText(""+temp);
    }

    public void addOneB(View view){
        TextView scoreKeeper = (TextView) findViewById(R.id.scoreKeeperB);
        int temp = Integer.parseInt(scoreKeeper.getText().toString());
        temp += 1;
        scoreKeeper.setText(""+temp);
    }

    public void addTwoB(View view){
        TextView scoreKeeper = (TextView) findViewById(R.id.scoreKeeperB);
        int temp = Integer.parseInt(scoreKeeper.getText().toString());
        temp += 2;
        scoreKeeper.setText(""+temp);
    }

    public void addThreeB(View view){
        TextView scoreKeeper = (TextView) findViewById(R.id.scoreKeeperB);
        int temp = Integer.parseInt(scoreKeeper.getText().toString());
        temp += 3;
        scoreKeeper.setText(""+temp);
    }

    public void reset(View view){
        TextView scoreKeeperA = (TextView) findViewById(R.id.scoreKeeperA);
        scoreKeeperA.setText("0");
        TextView scoreKeeperB = (TextView) findViewById(R.id.scoreKeeperB);
        scoreKeeperB.setText("0");
    }
}
