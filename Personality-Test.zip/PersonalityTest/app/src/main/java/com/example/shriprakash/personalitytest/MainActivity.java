package com.example.shriprakash.personalitytest;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    float Score = 0.0f;
    private RatingBar ratingBra;

    private float ratQ1(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ1);
        return ratingBra.getRating();
    }

    private float ratQ2(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ2);
        return ratingBra.getRating();
    }

    private float ratQ3(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ3);
        return ratingBra.getRating();
    }

    private float ratQ4(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ4);
        return ratingBra.getRating();
    }

    private float ratQ5(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ5);
        return ratingBra.getRating();
    }

    private float ratQ6(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ6);
        return ratingBra.getRating();
    }

    private float ratQ7(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ7);
        return ratingBra.getRating();
    }

    private float ratQ8(){
        ratingBra = (RatingBar) findViewById(R.id.ratQ8);
        return ratingBra.getRating();
    }

    @NonNull
    private String scoreCalculator(){
        Score = ratQ1();
        Score += ratQ2();
        Score += ratQ3();
        Score += ratQ4();
        Score += ratQ5();
        Score += ratQ6();
        Score += ratQ7();
        Score += ratQ8();

        return "Your Total Score is : "+Score +"\n"+personalityAnalyser();
    }

    public void analyseScore(View view){

        Toast.makeText(this,scoreCalculator(),Toast.LENGTH_LONG).show();
    }

    public void mailScore(View view){
        String msg = scoreCalculator()+ "\n" +
                "Thank You For Playing With Us!!!";
        Intent intentMail = new Intent(Intent.ACTION_SEND);
        intentMail.setData(Uri.parse("mailto:"));
        intentMail.setType("text/html");
        intentMail.putExtra(Intent.EXTRA_EMAIL,"shrisaiprakash99@gmail.com");
        intentMail.putExtra(Intent.EXTRA_SUBJECT,"Your Personality Test Score");
        intentMail.putExtra(Intent.EXTRA_TEXT,msg);
        startActivity(intentMail);
    }

    private String personalityAnalyser(){
        String temp = "";
        if(Score>=0.0f && Score<=8.0f){
            temp = "Need a Lot of Improvement.";
        }else if(Score >=9.0f && Score<=16.0f){
            temp = "Average Personality.";
        }else if(Score >=17.0f && Score<=24.0f){
            temp = "Good Personality";
        }else if(Score >=25.0f && Score <=32.0f){
            temp = "Excellent Personality.";
        }
        return temp;
    }

}
